# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - <short description>

    <what this stuff does ... - verbose enough>

    @copyright: 2006 by MoinMoin:YourNameHere 
    @license: GNU GPL, see COPYING for details.
"""


