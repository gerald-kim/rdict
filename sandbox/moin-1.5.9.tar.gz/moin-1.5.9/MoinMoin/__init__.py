# -*- coding: iso-8859-1 -*-
"""
MoinMoin Version 1.5.8 48e375393383+ tip

@copyright: 2000-2006 by J�rgen Hermann <jh@web.de>
@license: GNU GPL, see COPYING for details.
"""



