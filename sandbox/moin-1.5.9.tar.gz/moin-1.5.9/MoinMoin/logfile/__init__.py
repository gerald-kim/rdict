# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - LogFile package

    @copyright: 2005 by Thomas Waldmann (MoinMoin:ThomasWaldmann)
    @license: GNU GPL, see COPYING for details.
"""

from MoinMoin.util import pysupport

logfiles = pysupport.getPackageModules(__file__)

