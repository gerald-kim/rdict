# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - old style migration scripts

    @copyright: 2004 by Thomas Waldmann
    @license: GNU GPL, see COPYING for details.
"""

