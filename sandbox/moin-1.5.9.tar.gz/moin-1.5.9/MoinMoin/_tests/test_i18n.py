# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - MoinMoin.i18n Tests

    @copyright: 2003-2004 by J�rgen Hermann <jh@web.de>
    @license: GNU GPL, see COPYING for details.
"""

import unittest
from MoinMoin import i18n

class WhateverTestCase(unittest.TestCase):
    """... tests"""
    pass
