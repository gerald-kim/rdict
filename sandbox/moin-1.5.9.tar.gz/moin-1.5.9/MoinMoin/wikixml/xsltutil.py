# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - XSLT Utilities

    @copyright: 2001, 2003 by J�rgen Hermann <jh@web.de>
    @license: GNU GPL, see COPYING for details.
"""

## currently empty, due to adaption to 4Suite 1.0a1
## keep this file for later!

