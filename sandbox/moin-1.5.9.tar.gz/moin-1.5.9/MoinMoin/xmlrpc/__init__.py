# -*- coding: iso-8859-1 -*-
"""
    MoinMoin - xmlrpc extension modules Package

    @copyright: 2003-2004 by Thomas Waldmann
    @license: GNU GPL, see COPYING for details.
"""
from MoinMoin.util import pysupport

modules = pysupport.getPackageModules(__file__)
