# -*- coding: utf-8 -*-
# Text translations for Bahasa Indonesia (id).
# Automatically generated - DO NOT EDIT, edit id.po instead!
meta = {
  'language': """Bahasa Indonesia""",
  'elanguage': """Indonesian""",
  'maintainer': """Andy Apdhani <imtheface@gmail.com>""",
  'encoding': 'utf-8',
  'direction': 'ltr',
  'wikimarkup': True,
}
text = {
'''The backed up content of this page is deprecated and will not be included in search results!''':
'''Rekaman isi halaman ini sudah usang dan tidak akan disertakan dalam hasil pencarian!''',
'''Revision %(rev)d as of %(date)s''':
'''Revisi %(rev)d pada %(date)s''',
'''Redirected from page "%(page)s"''':
'''Dialihkan dari halaman "%(page)s"''',
'''This page redirects to page "%(page)s"''':
'''Halaman ini dialihkan ke halaman "%(page)s"''',
'''~-If you submit this form, the submitted values will be displayed.
To use this form on other pages, insert a
[[BR]][[BR]]\'\'\'{{{    [[Form("%(pagename)s")]]}}}\'\'\'[[BR]][[BR]]
macro call.-~
''':
'''~-Jika anda mengajukan isian ini, isi yang diajukan akan ditayangkan.
Untuk menggunakan isian ini pada halaman lain, masukkan
[[BR]][[BR]]\'\'\'{{{    [[Form("%(pagename)s")]]}}}\'\'\'[[BR]][[BR]]
menggunakan makro.-~
''',
'''Create New Page''':
'''Buat Halaman Baru''',
'''You are not allowed to view this page.''':
'''Anda tidak diizinkan menilik halaman ini.''',
'''You are not allowed to edit this page.''':
'''Anda tidak diizinkan menyunting halaman ini.''',
'''Page is immutable!''':
'''Halaman ini kekal!''',
'''Cannot edit old revisions!''':
'''Tidak dapat menyunting revisi lama''',
'''The lock you held timed out. Be prepared for editing conflicts!''':
'''Waktu penguncian yang anda lakukan telah habis. Siap-siap untuk konflik penyuntingan!''',
'''Edit "%(pagename)s"''':
'''Sunting "%(pagename)s"''',
'''Preview of "%(pagename)s"''':
'''Pratilik dari "%(pagename)s"''',
'''Your edit lock on %(lock_page)s has expired!''':
'''Waktu penguncian penyuntingan pada %(lock_page)s telah berakhir!''',
'''Your edit lock on %(lock_page)s will expire in # minutes.''':
'''Waktu penguncian penyuntingan pada %(lock_page)s akan berakhir dalam # menit.''',
'''Your edit lock on %(lock_page)s will expire in # seconds.''':
'''Waktu penguncian penyuntingan pada %(lock_page)s akan berakhir dalam # detik.''',
'''Someone else deleted this page while you were editing!''':
'''Orang lain telah menghapus halaman ini saat anda sedang menyuntingnya!''',
'''Someone else changed this page while you were editing!''':
'''Orang lain telah mengubah halaman ini saat anda menyuntingnya!''',
'''Someone else saved this page while you were editing!
Please review the page and save then. Do not save this page as it is!
Have a look at the diff of %(difflink)s to see what has been changed.''':
'''Orang lain telah menyimpan halaman ini saat anda sedang menyunting!
Silakan tilik ulang halaman dan simpan kemudian. Jangan simpan halaman ini dulu!
Coba lihat pada perbedaan dari %(difflink)s untuk melihat apa yang telah diubah.''',
'''[Content of new page loaded from %s]''':
'''[Isi halaman baru telah dimuat dari %s]''',
'''[Template %s not found]''':
'''[Templat %s tidak ditemukan]''',
'''[You may not read %s]''':
'''[Anda tidak boleh membaca %s]''',
'''Describe %s here.''':
'''Silakan tulis isi dari %s disini.''',
'''Check Spelling''':
'''Periksa Ejaan''',
'''Save Changes''':
'''Simpan Perubahan''',
'''Cancel''':
'''Batal''',
'''By hitting \'\'\'%(save_button_text)s\'\'\' you put your changes under the %(license_link)s.
If you don\'t want that, hit \'\'\'%(cancel_button_text)s\'\'\' to cancel your changes.''':
'''Dengan menekan \'\'\'%(save_button_text)s\'\'\' berarti anda menaruh perubahan anda dalam %(license_link)s.
Jika anda tidak menginginkannya, tekan \'\'\'%(cancel_button_text)s\'\'\' untuk membatalkan perubahan anda.''',
'''Preview''':
'''Pratilik''',
'''Text mode''':
'''Mode Teks''',
'''Comment:''':
'''Komentar:''',
'''<No addition>''':
'''<Tak ada kategori>''',
'''Add to: %(category)s''':
'''Kategori: %(category)s''',
'''Trivial change''':
'''Perubahan remeh-temeh''',
'''Remove trailing whitespace from each line''':
'''Hapus jejak spasi kosong dari setiap baris''',
'''Invalid user name {{{\'%s\'}}}.
Name may contain any Unicode alpha numeric character, with optional one
space between words. Group page name is not allowed.''':
'''Nama pengguna tidak benar {{{\'%s\'}}}.
Nama mungkin mengandung beberapa karakter alfanumerik Unicode, dengan satu spasi 
bebas-pilih diantara kata. Nama halaman grup tidak diizinkan.''',
'''You are not allowed to do %s on this page.''':
'''Anda tidak diizinkan melakukan %s di halaman ini.''',
'''Login and try again.''':
'''Masuk dan coba lagi.''',
'''%(hits)d results out of about %(pages)d pages.''':
'''%(hits)d hasil yang keluar mengenai halaman %(pages)d.''',
'''%.2f seconds''':
'''%.2f detik''',
'''match''':
'''cocok''',
'''matches''':
'''cocok''',
'''<unknown>''':
'''<tak diketahui>''',
'''Login Name: %s

Login Password: %s

Login URL: %s/%s?action=login
''':
'''Nama Login: %s

Kata Sandi: %s

URL Untuk Login: %s/%s?action=login
''',
'''Somebody has requested to submit your account data to this email address.

If you lost your password, please use the data below and just enter the
password AS SHOWN into the wiki\'s password form field (use copy and paste
for that).

After successfully logging in, it is of course a good idea to set a new and known password.
''':
'''Orang lain telah meminta untuk mengajukan data akun anda ke alamat email ini.

Jika anda kehilangan kata sandi, silakan gunakan data dibawah dan masukkan
kata sandi SEPERTI TERLIHAT di ruas formulir kata sandi wiki (gunakan salin dan rekat
untuk melakukannya).
''',
'''[%(sitename)s] Your wiki account data''':
'''[%(sitename)s] Data akun wiki anda''',
'''This wiki is not enabled for mail processing.
Contact the owner of the wiki, who can enable email.''':
'''Wiki ini tidak membolehkan untuk pengolahan surat.
Hubungi pengelola wiki, yang dapat membolehkan email.''',
'''Please provide a valid email address!''':
'''Silakan menyediakan alamat email yang benar!''',
'''Found no account matching the given email address \'%(email)s\'!''':
'''Tidak ditemukan akun yang cocok dengan alamat email ini \'%(email)s\'!''',
'''Use UserPreferences to change your settings or create an account.''':
'''Gunakan PreferensiPengguna untuk mengubah penataan atau membuat akun.''',
'''Empty user name. Please enter a user name.''':
'''Nama pengguna kosong. Silakan masukkan nama pengguna.''',
'''This user name already belongs to somebody else.''':
'''Nama pengguna sudah dimiliki oleh orang lain.''',
'''Passwords don\'t match!''':
'''Kata sandi tidak cocok!''',
'''Please specify a password!''':
'''Silakan tetapkan kata sandi!''',
'''Please provide your email address. If you lose your login information, you can get it by email.''':
'''Silakan sediakan alamat email anda. Jika anda kehilangan informasi login, anda dapat mendapatkan kembali melalui email.''',
'''This email already belongs to somebody else.''':
'''Email ini sudah dimiliki oleh orang lain.''',
'''User account created! You can use this account to login now...''':
'''Akun pengguna telah dibuat! Anda dapat menggunakan akun ini untuk login sekarang...''',
'''Use UserPreferences to change settings of the selected user account''':
'''Gunakan PreferensiPengguna untuk mengubah penataan akun pengguna terpilih''',
'''The theme \'%(theme_name)s\' could not be loaded!''':
'''Tema \'%(theme_name)s\' tidak dapat dimuat!''',
'''User preferences saved!''':
'''Menyimpan preferensi pengguna!''',
'''Default''':
'''Baku''',
'''<Browser setting>''':
'''<Setting browser>''',
'''the one preferred''':
'''yang disukai''',
'''free choice''':
'''pilihan bebas''',
'''Select User''':
'''Pilih Pengguna''',
'''Save''':
'''Simpan''',
'''Preferred theme''':
'''Tema yang diinginkan''',
'''Editor Preference''':
'''Preferensi Editor''',
'''Editor shown on UI''':
'''Antarmuka untuk Editor''',
'''Time zone''':
'''Zona waktu''',
'''Your time is''':
'''Waktu anda adalah''',
'''Server time is''':
'''Waktu server adalah''',
'''Date format''':
'''Format tanggal''',
'''Preferred language''':
'''Bahasa yang diinginkan''',
'''General options''':
'''Opsi umum''',
'''Quick links''':
'''Taut cepat''',
'''This list does not work, unless you have entered a valid email address!''':
'''Senarai ini tidak jalan, kecuali anda memasukkan alamat email yang benar!''',
'''Subscribed wiki pages (one regex per line)''':
'''Langganan halaman wiki (satu regex per baris)''',
'''Create Profile''':
'''Buat Profil''',
'''Mail me my account data''':
'''Kirim data akun saya lewat email''',
'''Email''':
'''Email''',
'''To create an account or recover a lost password, see the %(userprefslink)s page.''':
'''Gunakan halaman %(userprefslink)s untuk membuat akun atau memulihkan kata sandi yang hilang.''',
'''Name''':
'''Nama''',
'''Password''':
'''Kata sandi''',
'''Login''':
'''Masuk''',
'''Action''':
'''Aksi''',
'''Required attribute "%(attrname)s" missing''':
'''Atribut "%(attrname)s" yang dibutuhkan hilang''',
'''Submitted form data:''':
'''Data isian yang diajukan:''',
'''Search Titles''':
'''Cari Judul''',
'''Display context of search results''':
'''Tayangkan konteks dari hasil pencarian''',
'''Case-sensitive searching''':
'''Pencarian yang peka huruf besar-kecil''',
'''Search Text''':
'''Cari Teks''',
'''Go To Page''':
'''Ke Halaman''',
'''Include system pages''':
'''Menyertakan halaman sistem''',
'''Exclude system pages''':
'''Meniadakan halaman sistem''',
'''Plain title index''':
'''Indeks judul biasa''',
'''XML title index''':
'''Indeks judul XML''',
'''Python Version''':
'''Versi Python''',
'''MoinMoin Version''':
'''Versi MoinMoin''',
'''Release %s [Revision %s]''':
'''Luncuran %s [Revisi %s]''',
'''4Suite Version''':
'''Versi 4Suite''',
'''Number of pages''':
'''Jumlah halaman''',
'''Number of system pages''':
'''Jumlah halaman sistem''',
'''Accumulated page sizes''':
'''Akumulasi besar halaman''',
'''Disk usage of %(data_dir)s/pages/''':
'''Besar pemakaian cakram dari %(data_dir)s/pages/''',
'''Disk usage of %(data_dir)s/''':
'''Besar pemakaian cakram dari %(data_dir)s/''',
'''Entries in edit log''':
'''Entri di log sunting''',
'''NONE''':
'''TAK ADA''',
'''Global extension macros''':
'''Ekstensi makro global''',
'''Local extension macros''':
'''Ekstensi makro lokal''',
'''Global extension actions''':
'''Ekstensi aksi global''',
'''Local extension actions''':
'''Ekstensi aksi lokal''',
'''Global parsers''':
'''Pengurai global''',
'''Local extension parsers''':
'''Ekstensi pengurai lokal''',
'''Installed processors (DEPRECATED -- use Parsers instead)''':
'''Pemroses yang diinstal (USANG -- gunakan saja Pengurai)''',
'''Disabled''':
'''Lumpuhkan''',
'''Enabled''':
'''Aktifkan''',
'''Lupy search''':
'''Pencarian Lupy''',
'''Active threads''':
'''Ulir aktif''',
'''Please use a more selective search term instead of {{{"%s"}}}''':
'''Silakan menggunakan istilah pencarian yang lebih selektif daripada {{{"%s"}}}''',
'''ERROR in regex \'%s\'''':
'''KESALAHAN dalam regex \'%s\'''',
'''Bad timestamp \'%s\'''':
'''Stempel waktu buruk \'%s\'''',
'''Expected "=" to follow "%(token)s"''':
'''Diharapkan "=" mengikuti "%(token)s""''',
'''Expected a value for key "%(token)s"''':
'''Diharapkan nilai untuk kunci "%(token)s"''',
'''Wiki Markup''':
'''Markup Wiki''',
'''Print View''':
'''Tilik Cetakan''',
'''Your changes are not saved!''':
'''Perubahan anda tidak disimpan!''',
'''Page name is too long, try shorter name.''':
'''Nama halaman terlalu panjang, coba yang lebih singkat.''',
'''GUI Mode''':
'''Mode GUI''',
'''Edit was cancelled.''':
'''Penyuntingan dibatalkan.''',
'''You can\'t rename to an empty pagename.''':
'''Anda tidak dapat mengganti nama pada halaman kosong.''',
'''\'\'\'A page with the name {{{\'%s\'}}} already exists.\'\'\'

Try a different name.''':
'''\'\'\'Halaman dengan nama {{{\'%s\'}}} sudah ada.\'\'\'

Coba nama yang lain.''',
'''Could not rename page because of file system error: %s.''':
'''Tidak dapat mengganti nama halaman karena kesalahan sistem berkas: %s.''',
'''Thank you for your changes. Your attention to detail is appreciated.''':
'''Terima kasih atas perubahan anda. Perhatian anda pada dokumen ini sangat dihargai.''',
'''Page "%s" was successfully deleted!''':
'''Halaman "%s" berhasil dihapus!''',
'''Dear Wiki user,

You have subscribed to a wiki page or wiki category on "%(sitename)s" for change notification.

The following page has been changed by %(editor)s:
%(pagelink)s

''':
'''Pengguna Wiki YTH,

Anda berlangganan ke halaman wiki atau kategori wiki pada "%(sitename)s" untuk pemberitahuan perubahan.

Halaman berikut telah diubah oleh %(editor)s:
%(pagelink)s

''',
'''The comment on the change is:
%(comment)s

''':
'''Komentar pada perubahan ini:
%(comment)s

''',
'''New page:
''':
'''Halaman baru:
''',
'''No differences found!
''':
'''Tidak ditemukan perbedaan!
''',
'''[%(sitename)s] %(trivial)sUpdate of "%(pagename)s" by %(username)s''':
'''[%(sitename)s] %(trivial)sPemutakhiran dari "%(pagename)s" oleh %(username)s''',
'''Trivial ''':
'''Remeh-temeh ''',
'''Status of sending notification mails:''':
'''Status pengiriman surat pemberitahuan:''',
'''[%(lang)s] %(recipients)s: %(status)s''':
'''[%(lang)s] %(recipients)s: %(status)s''',
'''## backup of page "%(pagename)s" submitted %(date)s''':
'''## rekaman dari halaman "%(pagename)s" diajukan pada %(date)s''',
'''Page could not get locked. Unexpected error (errno=%d).''':
'''Halaman tidak dapat dikunci. Kesalahan yang tak diduga (errno=%d).''',
'''Page could not get locked. Missing \'current\' file?''':
'''Halaman tidak dapat dikunci. Tidak ada berkas \'current\'?\'''',
'''You are not allowed to edit this page!''':
'''Anda tidak diizinkan menyunting halaman ini!''',
'''You cannot save empty pages.''':
'''Anda tidak dapat menyimpan halaman kosong.''',
'''You already saved this page!''':
'''Anda telah menyimpan halaman ini!''',
'''Sorry, someone else saved the page while you edited it.

Please do the following: Use the back button of your browser, and cut&paste
your changes from there. Then go forward to here, and click EditText again.
Now re-add your changes to the current page contents.

\'\'Do not just replace
the content editbox with your version of the page, because that would
delete the changes of the other person, which is excessively rude!\'\'
''':
'''Maaf, orang lain telah menyimpan halaman ini saat anda menyuntingnya.

Silakan lakukan ini: Gunakan tombol ke belakang dari peramban anda, dan potong&rekat
perubahan anda dari sana. Kemudian balik kembali, dan klik SuntingTeks lagi.
Sekarang tambah ulang perubahan anda pada isi halaman sekarang.

\'\'Jangan langsung mengganti
isi dalam kotak sunting dengan versi halaman anda, karena itu akan
menghapus perubahan dari orang lain, dan itu sangat tidak sopan!\'\'
''',
'''A backup of your changes is [%(backup_url)s here].''':
'''Rekaman dari perubahan anda ada [%(backup_url)s disini].''',
'''You did not change the page content, not saved!''':
'''Anda tidak mengubah isi halaman, tidak disimpan!''',
'''You can\'t change ACLs on this page since you have no admin rights on it!''':
'''Anda tidak dapat mengubah ACL pada halaman ini karena tidak punya hak izin admin!''',
'''The lock of %(owner)s timed out %(mins_ago)d minute(s) ago, and you were granted the lock for this page.''':
'''Penguncian oleh %(owner)s berakhir %(mins_ago)d menit lalu, dan anda sekarang dapat mengunci halaman ini.''',
'''Other users will be \'\'blocked\'\' from editing this page until %(bumptime)s.''':
'''Pengguna lain akan \'\'diblokir\'\' dari penyuntingan halaman ini sampai %(bumptime)s.''',
'''Other users will be \'\'warned\'\' until %(bumptime)s that you are editing this page.''':
'''Pengguna lain akan \'\'diperingatkan\'\' sampai %(bumptime)s bahwa anda sedang menyunting halaman ini.''',
'''Use the Preview button to extend the locking period.''':
'''Gunakan tombol Pratilik untuk memperpanjang waktu penguncian.''',
'''This page is currently \'\'locked\'\' for editing by %(owner)s until %(timestamp)s, i.e. for %(mins_valid)d minute(s).''':
'''Halaman ini sedang \'\'dikunci\'\' untuk penyuntingan oleh %(owner)s sampai %(timestamp)s, contoh untuk %(mins_valid)d menit.''',
'''This page was opened for editing or last previewed at %(timestamp)s by %(owner)s.[[BR]]
\'\'\'You should \'\'refrain from editing\'\' this page for at least another %(mins_valid)d minute(s),
to avoid editing conflicts.\'\'\'[[BR]]
To leave the editor, press the Cancel button.''':
'''Halaman ini terbuka untuk penyuntingan atau pratilik terakhir pada %(timestamp)s oleh %(owner)s.[[BR]]
\'\'\'Anda harus \'\'tunda dulu penyuntingan\'\' halaman ini setidaknya sampai %(mins_valid)d menit lagi,
untuk menghindari konflik penyuntingan.\'\'\'[[BR]]
Untuk meninggalkan editor, tekan tombol Batal.''',
'''The package needs a newer version of MoinMoin (at least %s).''':
'''Paket ini membutuhkan MoinMoin versi terbaru (sekurangnya %s).''',
'''The theme name is not set.''':
'''Nama tema tidak ditata.''',
'''Installing theme files is only supported for standalone type servers.''':
'''Menginstal berkas tema hanya didukung untuk server mandiri.''',
'''Installation of \'%(filename)s\' failed.''':
'''Instalasi dari \'%(filename)s\' gagal.''',
'''The file %s is not a MoinMoin package file.''':
'''Berkas %s bukan berkas paket MoinMoin.''',
'''The page %s does not exist.''':
'''Halaman %s tidak ada.''',
'''Invalid package file header.''':
'''Header berkas paket tidak benar.''',
'''Package file format unsupported.''':
'''Format berkas paket tidak didukung.''',
'''Unknown function %(func)s in line %(lineno)i.''':
'''Fungsi yang tak dikenal %(func)s di baris %(lineno)i.''',
'''The file %s was not found in the package.''':
'''Berkas %s tidak ditemukan di dalam paket.''',
''' Emphasis:: [[Verbatim(\'\')]]\'\'italics\'\'[[Verbatim(\'\')]]; [[Verbatim(\'\'\')]]\'\'\'bold\'\'\'[[Verbatim(\'\'\')]]; [[Verbatim(\'\'\'\'\')]]\'\'\'\'\'bold italics\'\'\'\'\'[[Verbatim(\'\'\'\'\')]]; [[Verbatim(\'\')]]\'\'mixed \'\'[[Verbatim(\'\'\')]]\'\'\'\'\'bold\'\'\'[[Verbatim(\'\'\')]] and italics\'\'[[Verbatim(\'\')]]; [[Verbatim(----)]] horizontal rule.
 Headings:: [[Verbatim(=)]] Title 1 [[Verbatim(=)]]; [[Verbatim(==)]] Title 2 [[Verbatim(==)]]; [[Verbatim(===)]] Title 3 [[Verbatim(===)]];   [[Verbatim(====)]] Title 4 [[Verbatim(====)]]; [[Verbatim(=====)]] Title 5 [[Verbatim(=====)]].
 Lists:: space and one of: * bullets; 1., a., A., i., I. numbered items; 1.#n start numbering at n; space alone indents.
 Links:: [[Verbatim(JoinCapitalizedWords)]]; [[Verbatim(["brackets and double quotes"])]]; url; [url]; [url label].
 Tables:: || cell text |||| cell text spanning 2 columns ||;    no trailing white space allowed after tables or titles.

(!) For more help, see HelpOnEditing or SyntaxReference.
''':
''' Penekanan:: [[Verbatim(\'\')]]\'\'teks miring\'\'[[Verbatim(\'\')]]; [[Verbatim(\'\'\')]]\'\'\'teks tebal\'\'\'[[Verbatim(\'\'\')]]; [[Verbatim(\'\'\'\'\')]]\'\'\'\'\'tebal miring\'\'\'\'\'[[Verbatim(\'\'\'\'\')]]; [[Verbatim(\'\')]]\'\'gabungan \'\'[[Verbatim(\'\'\')]]\'\'\'\'\'teks tebal\'\'\'[[Verbatim(\'\'\')]] dan teks miring\'\'[[Verbatim(\'\')]]; [[Verbatim(----)]] garis horisontal.
 Heading:: [[Verbatim(=)]] Judul 1 [[Verbatim(=)]]; [[Verbatim(==)]] Judul 2 [[Verbatim(==)]]; [[Verbatim(===)]] Judul 3 [[Verbatim(===)]];   [[Verbatim(====)]] Judul 4 [[Verbatim(====)]]; [[Verbatim(=====)]] Judul 5 [[Verbatim(=====)]].
 Senarai:: Gunakan spasi dan satu dari tanda: * bulet; 1., a., A., i., I. butir bernomor; 1.#n mulai penomoran pada n; spasi saja akan menjadi indent.
 Taut:: [[Verbatim(KataGabungan)]]; [[Verbatim(["tanda kurung kotak dan tanda kutip ganda"])]]; url; [url]; [url label].
 Tabel:: || teks sel |||| teks sel merentang 2 kolom ||;    tidak boleh ada jejak spasi kosong setelah tabel atau judul.

(!) Untuk bantuan lebih lanjut, lihat BantuanPenyuntingan atau ReferensiSintaksis.
''',
'''Emphasis: <i>*italic*</i> <b>**bold**</b> ``monospace``<br/>
<br/><pre>
Headings: Heading 1  Heading 2  Heading 3
          =========  ---------  ~~~~~~~~~

Horizontal rule: ---- 
Links: TrailingUnderscore_ `multi word with backticks`_ external_ 

.. _external: http://external-site.net/foo/

Lists: * bullets; 1., a. numbered items.
</pre>
<br/>
(!) For more help, see the 
<a href="http://docutils.sourceforge.net/docs/user/rst/quickref.html">
reStructuredText Quick Reference
</a>.
''':
'''Penekanan: <i>*teks miring*</i> <b>**teks tebal**</b> ``huruf monospace``<br/>
<br/><pre>
Heading: Heading 1  Heading 2  Heading 3
          =========  ---------  ~~~~~~~~~

Mistar horisontal: ---- 
Taut: MengekorGarisbawah_ `banyak kata dengan kutip kebelakang`_ keluar_ 

.. _keluar: http://external-site.net/foo/

Senarai: * bulet; 1., a. butir bernomor.
</pre>
<br/>
(!) Untuk bantuan lebih banyak, lihat 
<a href="http://docutils.sourceforge.net/docs/user/rst/quickref.html">
Referensi Cepat reStructuredText
</a>.
''',
'''Diffs''':
'''Perbedaan''',
'''Info''':
'''Info''',
'''Edit''':
'''Sunting''',
'''UnSubscribe''':
'''BatalBerlangganan''',
'''Subscribe''':
'''Berlangganan''',
'''Raw''':
'''Mentah''',
'''XML''':
'''XML''',
'''Print''':
'''Cetak''',
'''View''':
'''Tilik''',
'''Up''':
'''Atas''',
'''Publish my email (not my wiki homepage) in author info''':
'''Tampilkan email saya di info pengarang''',
'''Open editor on double click''':
'''Buka editor dengan klik dua kali''',
'''Jump to last visited page instead of frontpage''':
'''Loncat ke halaman terakhir dikunjungi daripada ke halaman muka''',
'''Show question mark for non-existing pagelinks''':
'''Tampilkan tanda tanya untuk taut ke halaman kosong''',
'''Show page trail''':
'''Tampilkan jejak halaman''',
'''Show icon toolbar''':
'''Tampilkan ikon toolbar''',
'''Show top/bottom links in headings''':
'''Tampilkan taut atas/bawah di heading''',
'''Show fancy diffs''':
'''Menampilkan perbedaaan dengan cantik''',
'''Add spaces to displayed wiki names''':
'''Tambah spasi untuk menayangkan nama wiki''',
'''Remember login information''':
'''Ingat informasi login''',
'''Subscribe to trivial changes''':
'''Berlangganan ke perubahan remeh-temeh''',
'''Disable this account forever''':
'''Tutup akun ini selamanya''',
'''(Use Firstname\'\'\'\'\'\'Lastname)''':
'''(Gunakan nama Awal\'\'\'\'\'\'Nama akhir)''',
'''Alias-Name''':
'''Nama Alias''',
'''Password repeat''':
'''Ulangi kata sandi''',
'''(Only when changing passwords)''':
'''(Hanya saat membuat kata sandi baru)''',
'''User CSS URL''':
'''URL untuk CSS pribad''',
'''(Leave it empty for disabling user CSS)''':
'''(Kosongkan jika tidak ingin menggunakan CSS pribadi)''',
'''Editor size''':
'''Ukuran editor''',
'''No older revisions available!''':
'''Revisi terdahulu tak tersedia!''',
'''Diff for "%s"''':
'''Perbedaan untuk "%s"''',
'''Differences between revisions %d and %d''':
'''Perbedaan antara revisi %d dan %d''',
'''(spanning %d versions)''':
'''(rentang %d versi)''',
'''No differences found!''':
'''Tidak ditemukan perbedaan!''',
'''The page was saved %(count)d times, though!''':
'''Halaman tersimpan sebanyak %(count)d kali!''',
'''(ignoring whitespace)''':
'''(mengabaikan spasi kosong)''',
'''Ignore changes in the amount of whitespace''':
'''Abaikan perubahan hanya karena beda di spasi kosong''',
'''General Information''':
'''Informasi Umum''',
'''Page size: %d''':
'''Besar halaman: %d''',
'''SHA digest of this page\'s content is:''':
'''Digest SHA dari isi halaman ini adalah:''',
'''The following users subscribed to this page:''':
'''Pengguna yang berlangganan ke halaman ini:''',
'''This page links to the following pages:''':
'''Halaman ini bertaut ke halaman berikut:''',
'''Date''':
'''Tanggal''',
'''Size''':
'''Ukuran''',
'''Diff''':
'''Beda''',
'''Editor''':
'''Editor''',
'''Comment''':
'''Keterangan''',
'''view''':
'''tilik''',
'''raw''':
'''mentah''',
'''print''':
'''cetak''',
'''revert''':
'''putar balik''',
'''Revert to revision %(rev)d.''':
'''Putar balik ke revisi %(rev)d.''',
'''edit''':
'''sunting''',
'''get''':
'''ambil''',
'''del''':
'''hapus''',
'''N/A''':
'''T/A''',
'''Revision History''':
'''Riwayat Revisi''',
'''No log entries found.''':
'''Tidak ditemukan entri log.''',
'''Info for "%s"''':
'''Info untuk "%s"''',
'''Show "%(title)s"''':
'''Tampilkan "%(title)s"''',
'''General Page Infos''':
'''Info Halaman Umum''',
'''Show chart "%(title)s"''':
'''Tampilkan bagan "%(title)s"''',
'''Page hits and edits''':
'''Jumlah pengunjung dan penyuntingan''',
'''You are not allowed to revert this page!''':
'''Anda tidak diizinkan memutar balik halaman ini!''',
'''You must login to add a quicklink.''':
'''Anda harus login untuk menambah taut cepat.''',
'''Your quicklink to this page has been removed.''':
'''Taut cepat anda ke halaman ini telah dihapus.''',
'''A quicklink to this page has been added for you.''':
'''Taut cepat ke halaman ini telah ditambahkan untuk anda.''',
'''You are not allowed to subscribe to a page you can\'t read.''':
'''Anda tidak diizinkan berlangganan ke halaman yang tak dapat anda baca''',
'''This wiki is not enabled for mail processing.''':
'''Wiki ini tidak diaktifkan untuk pengelolaan surat.''',
'''You must log in to use subscribtions.''':
'''Anda harus login untuk berlangganan.''',
'''Add your email address in your UserPreferences to use subscriptions.''':
'''Tambah alamat email anda dalam PreferensiPengguna untuk berlangganan.''',
'''Your subscribtion to this page has been removed.''':
'''Langganan anda ke halaman ini telah dihapus.''',
'''Can\'t remove regular expression subscription!''':
'''Tidak dapat menghapus ekspresi regular pada langganan!''',
'''Edit the subscription regular expressions in your UserPreferences.''':
'''Sunting ekspresi regular pada langganan dalam PreferensiPengguna anda.''',
'''You have been subscribed to this page.''':
'''Anda berlangganan ke halaman ini.''',
'''Charts are not available!''':
'''Bagan tidak tersedia!''',
'''You need to provide a chart type!''':
'''Anda harus menyediakan tipe bagan!''',
'''Bad chart type "%s"!''':
'''Tipe bagan buruk "%s"!''',
'''This page is already deleted or was never created!''':
'''Halaman ini telah dihapus atau belum pernah dibuat!''',
'''No pages like "%s"!''':
'''Tak ada halaman seperti "%s"!''',
'''Invalid filename "%s"!''':
'''Nama berkas tidak benar: "%s"!''',
'''Attachment \'%(target)s\' (remote name \'%(filename)s\') already exists.''':
'''Lampiran \'%(target)s\' (nama remote \'%(filename)s\') sudah ada.''',
'''Created the package %s containing the pages %s.''':
'''Membuat paket %s yang memuat halaman %s.''',
'''Package pages''':
'''Halaman paket''',
'''Package name''':
'''Nama paket''',
'''List of page names - separated by a comma''':
'''Senarai nama halaman - pisahkan dengan koma''',
'''Unknown user name: {{{"%s"}}}. Please enter user name and password.''':
'''Nama pengguna tak diketahui: {{{"%s"}}}. Silakan masukkan nama pengguna dan kata sandi.''',
'''Missing password. Please enter user name and password.''':
'''Kurang kata sandi. Silakan masukkan nama pengguna dan kata sandi.''',
'''Sorry, wrong password.''':
'''Maaf, kata sandi salah.''',
'''Exactly one page like "%s" found, redirecting to page.''':
'''Tepat satu halaman seperti "%s" ditemukan, dialihkan ke halaman.''',
'''Pages like "%s"''':
'''Halaman seperti "%s"''',
'''%(matchcount)d %(matches)s for "%(title)s"''':
'''%(matchcount)d %(matches)s untuk "%(title)s"''',
'''Local Site Map for "%s"''':
'''Site Map Lokal untuk "%s"''',
'''Please log in first.''':
'''Silakan login dahulu.''',
'''Please first create a homepage before creating additional pages.''':
'''Silakan buat laman dulu sebelum membuat halaman tambahan.''',
'''You can add some additional sub pages to your already existing homepage here.

You can choose how open to other readers or writers those pages shall be,
access is controlled by group membership of the corresponding group page.

Just enter the sub page\'s name and click on the button to create a new page.

Before creating access protected pages, make sure the corresponding group page
exists and has the appropriate members in it. Use HomepageGroupsTemplate for creating
the group pages.

||\'\'\'Add a new personal page:\'\'\'||\'\'\'Related access control list group:\'\'\'||
||[[NewPage(HomepageReadWritePageTemplate,read-write page,%(username)s)]]||["%(username)s/ReadWriteGroup"]||
||[[NewPage(HomepageReadPageTemplate,read-only page,%(username)s)]]||["%(username)s/ReadGroup"]||
||[[NewPage(HomepagePrivatePageTemplate,private page,%(username)s)]]||%(username)s only||

''':
'''Anda dapat menambah beberapa sub halaman ke laman anda yang sudah ada disini.

Anda dapat memilih askes halaman tersebut untuk pembaca atau penulis lain ,
akses di kontrol oleh keanggotaan grup dari grup halaman yang bersangkutan.

Cukup masukkan nama sub halaman dan klik pada tombol buat halaman baru.

Sebelum membuat akses proteksi halaman, pastikan grup halaman yang bersangkutan
ada dan punya anggota yang tepat di dalamnya. Gunakan TemplatLamanGrup untuk membuat
halaman grup.

||\'\'\'Tambah halaman pribadi baru:\'\'\'||\'\'\'Senarai grup kontrol akses:\'\'\'||
||[[NewPage(HomepageReadWritePageTemplate,halaman baca-tulis,%(username)s)]]||["%(username)s/ReadWriteGroup"]||
||[[NewPage(HomepageReadPageTemplate,halaman baca saja,%(username)s)]]||["%(username)s/ReadGroup"]||
||[[NewPage(HomepagePrivatePageTemplate,halaman pribadi,%(username)s)]]||%(username)s saja||

''',
'''MyPages management''':
'''Manajemen HalamanSaya''',
'''Rename Page''':
'''Ganti Nama Halaman''',
'''New name''':
'''Nama baru''',
'''Optional reason for the renaming''':
'''Alasan dari penggantian nama''',
'''(including %(localwords)d %(pagelink)s)''':
'''(menyertakan %(localwords)d %(pagelink)s)''',
'''The following %(badwords)d words could not be found in the dictionary of %(totalwords)d words%(localwords)s and are highlighted below:''':
'''%(badwords)d kata berikut ini tidak dapat ditemukan di kamus yang mempunyai %(totalwords)d kata%(localwords)s dan kata tersebut dapat dilihat dibawah:''',
'''Add checked words to dictionary''':
'''Tambah kata terpilih ke dalam kamus''',
'''No spelling errors found!''':
'''Tak ditemukan kesalahan ejaan!''',
'''You can\'t check spelling on a page you can\'t read.''':
'''Anda tidak dapat memeriksa ejaan pada halaman yang tidak dapat anda baca.''',
'''Do it.''':
'''Lakukan''',
'''Execute action %(actionname)s?''':
'''Menjalankan aksi %(actionname)s?''',
'''Action %(actionname)s is excluded in this wiki!''':
'''Aksi %(actionname)s tidak disertakan dalam wiki ini!''',
'''You are not allowed to use action %(actionname)s on this page!''':
'''Anda tidak diizinkan untuk menggunakan aksi %(actionname)s di halaman ini!''',
'''Please use the interactive user interface to use action %(actionname)s!''':
'''Silakan gunakan antarmuka pengguna interaktif untuk menggunakan aksi %(actionname)s!''',
'''Title Search: "%s"''':
'''Cari Judul: "%s"''',
'''Full Text Search: "%s"''':
'''Cari Teks Penuh: "%s"''',
'''Full Link List for "%s"''':
'''Senarai Taut Penuh untuk "%s"''',
'''Cannot create a new page without a page name.  Please specify a page name.''':
'''Tidak dapat membuat halaman baru tanpa nama. Silakan tetapkan nama halaman.''',
'''Pages''':
'''Halaman''',
'''Select Author''':
'''Pilih Penulis''',
'''Revert all!''':
'''Putar balik semua!''',
'''You are not allowed to use this action.''':
'''Anda tidak diizinkan menggunakan aksi ini.''',
'''Subscribe users to the page %s''':
'''Pengguna yang berlangganan ke halaman %s''',
'''Subscribed for %s:''':
'''Berlanggananan untuk %s:''',
'''Not a user:''':
'''Bukan pengguna:''',
'''You are not allowed to perform this action.''':
'''Anda tidak diizinkan melakukan aksi ini.''',
'''You are now logged out.''':
'''Sekarang anda telah logout.''',
'''Delete''':
'''Hapus''',
'''Optional reason for the deletion''':
'''Alasan dari penghapusan''',
'''Really delete this page?''':
'''Yakin menghapus halaman ini?''',
'''Restored Backup: %(filename)s to target dir: %(targetdir)s.
Files: %(filecount)d, Directories: %(dircount)d''':
'''Simpan Ulang Rekaman: %(filename)s ke direktori tujuan: %(targetdir)s.
Berkas: %(filecount)d, Direktori: %(dircount)d''',
'''Restoring backup: %(filename)s to target dir: %(targetdir)s failed.''':
'''Menyimpan ulang rekaman: %(filename)s ke direktori tujuan: %(targetdir)s gagal.''',
'''Wiki Backup / Restore''':
'''Merekam / Menyimpan Ulang Wiki''',
'''Some hints:
 * To restore a backup:
  * Restoring a backup will overwrite existing data, so be careful.
  * Rename it to <siteid>.tar.<compression> (remove the --date--time--UTC stuff).
  * Put the backup file into the backup_storage_dir (use scp, ftp, ...).
  * Hit the [[GetText(Restore)]] button below.

 * To make a backup, just hit the [[GetText(Backup)]] button and save the file
   you get to a secure place.

Please make sure your wiki configuration backup_* values are correct and complete.

''':
'''Beberapa petunjuk:
 * Untuk memulihkan rekaman:
  * Memulihkan rekaman akan menimpa data yang ada, jadi hati-hati.
  * Ganti nama ke <id_situs>.tar.<kompresi> (hapus bagian --tanggal--jam--UTC).
  * Taruh berkas rekaman ke backup_storage_dir (gunakan scp, ftp, ...).
  * Tekan tombol [[GetText(Restore)]] dibawah.

 * Untuk membuat backup, cukup tekan tombol [[GetText(Backup)]] dan simpan berkas backup ditempat yang aman.

Tolong pastikan nilai konfigurasi backup_* wiki anda benar dan lengkap.

''',
'''Backup''':
'''Backup''',
'''Restore''':
'''Kembalikan''',
'''You are not allowed to do remote backup.''':
'''Anda tidak diizinkan mem-backup dari jauh.''',
'''Unknown backup subaction: %s.''':
'''Sub aksi untuk backup tidak diketahui: %s.''',
'''[%d attachments]''':
'''[%d lampiran]''',
'''There are <a href="%(link)s">%(count)s attachment(s)</a> stored for this page.''':
'''Ada <a href="%(link)s">%(count)s lampiran</a> yang disimpan di halaman ini.''',
'''Filename of attachment not specified!''':
'''Nama berkas dari lampiran tidak ditetapkan!''',
'''Attachment \'%(filename)s\' does not exist!''':
'''Lampiran \'%(filename)s\' tidak ada!''',
'''To refer to attachments on a page, use \'\'\'{{{attachment:filename}}}\'\'\', 
as shown below in the list of files. 
Do \'\'\'NOT\'\'\' use the URL of the {{{[get]}}} link, 
since this is subject to change and can break easily.''':
'''Untuk menggunakan lampiran pada halaman, gunakan \'\'\'{{{attachment:filename}}}\'\'\', 
seperti yang ditampilkan di dalam senarai berkas. 
\'\'\'JANGAN\'\'\' menggunakan URL dari taut {{{[get]}}}, 
karena hal ini akan dan bisa berubah setiap saat.''',
'''unzip''':
'''unzip''',
'''install''':
'''instal''',
'''No attachments stored for %(pagename)s''':
'''Tak ada lampiran tersimpan untuk %(pagename)s''',
'''Edit drawing''':
'''Sunting penggambaran''',
'''Attached Files''':
'''Lampirkan Berkas''',
'''You are not allowed to attach a file to this page.''':
'''Anda tidak diizinkan untuk melampirkan berkas ke halaman ini.''',
'''New Attachment''':
'''Lampiran Baru''',
'''An upload will never overwrite an existing file. If there is a name
conflict, you have to rename the file that you want to upload.
Otherwise, if "Rename to" is left blank, the original filename will be used.''':
'''Setiap berkas yang di-upload tidak akan menimpa yang sudah ada. Jika terjadi konflik
nama, anda harus mengganti nama berkas yang ingin anda upload.
Sebaliknya, jika "Ganti Nama ke" dikosongkan, nama berkas semula yang dipakai.''',
'''File to upload''':
'''Berkas untuk di-upload''',
'''Rename to''':
'''Ganti nama ke''',
'''Upload''':
'''Upload''',
'''File attachments are not allowed in this wiki!''':
'''Tidak diizinkan melampirkan berkas di wiki ini!''',
'''You are not allowed to save a drawing on this page.''':
'''Anda tidak diizinkan menyimpan penggambaran pada halaman ini''',
'''No file content. Delete non ASCII characters from the file name and try again.''':
'''Tak ada isi berkas. Hapus karakter bukan ASCII dari nama berkas dan coba lagi.''',
'''You are not allowed to delete attachments on this page.''':
'''Anda tidak diizinkan menghapus lampiran pada halaman ini.''',
'''You are not allowed to get attachments from this page.''':
'''Anda tidak diizinkan mengambil lampiran dari halaman ini.''',
'''You are not allowed to unzip attachments of this page.''':
'''Anda tidak diizinkan untuk meng-unzip lampiran dari halaman ini.''',
'''You are not allowed to install files.''':
'''Anda tidak diizinkan menginstal berkas.''',
'''You are not allowed to view attachments of this page.''':
'''Anda tidak diizinkan menilik lampiran dari halaman ini.''',
'''Unsupported upload action: %s''':
'''Aksi upload yang tidak disupport: %s''',
'''Attachments for "%(pagename)s"''':
'''Lampiran untuk "%(pagename)s"''',
'''Attachment \'%(target)s\' (remote name \'%(filename)s\') with %(bytes)d bytes saved.''':
'''Lampiran \'%(target)s\' (nama jauh \'%(filename)s\') dengan %(bytes)d bita disimpan.''',
'''Attachment \'%(filename)s\' deleted.''':
'''Lampiran \'%(filename)s\' dihapus.''',
'''Attachment \'%(filename)s\' installed.''':
'''\'Lampiran \'%(filename)s\' diinstal.''',
'''Attachment \'%(filename)s\' could not be unzipped because the resulting files would be too large (%(space)d kB missing).''':
'''Tak dapat meng-unzip lampiran \'%(filename)s\' karena berkas yang dihasilkan terlalu besar (hilang %(space)d kB).''',
'''Attachment \'%(filename)s\' could not be unzipped because the resulting files would be too many (%(count)d missing).''':
'''Tak dapat meng-unzip lampiran \'%(filename)s\' karena berkas yang dihasilkan terlalu banyak (hilang %(count)d).''',
'''Attachment \'%(filename)s\' unzipped.''':
'''Meng-unzip lampiran \'%(filename)s\'.''',
'''Attachment \'%(filename)s\' not unzipped because the files are too big, .zip files only, exist already or reside in folders.''':
'''Tak dapat meng-unzip lampiran \'%(filename)s\' karena berkas terlalu besar, berkas .zip saja, sudah ada atau terletak di dalam pelipat.''',
'''The file %(target)s is not a .zip file.''':
'''Berkas %(target)s bukan berkas .zip.''',
'''Attachment \'%(filename)s\'''':
'''Lampiran \'%(filename)s\'''',
'''Package script:''':
'''Skrip paket:''',
'''File Name''':
'''Nama Berkas''',
'''Modified''':
'''Diubah''',
'''Unknown file type, cannot display this attachment inline.''':
'''Tipe berkas tak dikenal, tak dapat menayangkan lampiran ini.''',
'''attachment:%(filename)s of %(pagename)s''':
'''lampiran:%(filename)s dari %(pagename)s''',
'''Upload new attachment "%(filename)s"''':
'''Upload lampiran baru "%(filename)s"''',
'''Create new drawing "%(filename)s"''':
'''Buat penggambaran baru "%(filename)s"''',
'''Edit drawing %(filename)s''':
'''Sunting penggambaran %(filename)s''',
'''Toggle line numbers''':
'''On/Off nomor baris''',
'''FrontPage''':
'''HalamanMuka''',
'''RecentChanges''':
'''PerubahanTerbaru''',
'''TitleIndex''':
'''IndeksJudul''',
'''WordIndex''':
'''IndeksKata''',
'''FindPage''':
'''CariHalaman''',
'''SiteNavigation''':
'''NavigasiSitus''',
'''HelpContents''':
'''DaftarBantuan''',
'''HelpOnFormatting''':
'''BantuanPemformatan''',
'''UserPreferences''':
'''PreferensiPengguna''',
'''WikiLicense''':
'''LisensiWiki''',
'''MissingPage''':
'''HalamanHilang''',
'''MissingHomePage''':
'''LamanHilang''',
'''Mon''':
'''Sen''',
'''Tue''':
'''Sel''',
'''Wed''':
'''Rab''',
'''Thu''':
'''Kam''',
'''Fri''':
'''Jum''',
'''Sat''':
'''Sab''',
'''Sun''':
'''Min''',
'''AttachFile''':
'''LampirkanBerkas''',
'''DeletePage''':
'''HapusHalaman''',
'''LikePages''':
'''HalamanSerupa''',
'''LocalSiteMap''':
'''PetaSitusLokal''',
'''RenamePage''':
'''GantiNamaHalaman''',
'''SpellCheck''':
'''CekEjaan''',
'''Invalid MonthCalendar calparms "%s"!''':
'''Calparms KalendarBulanan tidak benar "%s"!''',
'''Invalid MonthCalendar arguments "%s"!''':
'''Argumen KalendarBulanan tidak benar "%s"!''',
'''Unsupported navigation scheme \'%(scheme)s\'!''':
'''Skema navigasi tidak didukung \'%(scheme)s\'!''',
'''No parent page found!''':
'''Tidak ditemukan halaman induk!''',
'''Wiki''':
'''Wiki''',
'''Slideshow''':
'''Slideshow''',
'''Start''':
'''Mulai''',
'''Slide %(pos)d of %(size)d''':
'''Slide %(pos)d dari %(size)d''',
'''No orphaned pages in this wiki.''':
'''Tidak ada halaman yatim di wiki ini.''',
'''No quotes on %(pagename)s.''':
'''Tidak ada kutipan pada %(pagename)s.''',
'''Upload of attachment \'%(filename)s\'.''':
'''Upload lampiran \'%(filename)s\'.''',
'''Drawing \'%(filename)s\' saved.''':
'''Penggambaran \'%(filename)s\' disimpan.''',
'''%(mins)dm ago''':
'''%(mins)dm yang lalu''',
'''(no bookmark set)''':
'''(tak ada bookmark yang ditata)''',
'''(currently set to %s)''':
'''(saat ini ditata ke %s)''',
'''Delete Bookmark''':
'''Hapus Bookmark''',
'''Set bookmark''':
'''Tata bookmark''',
'''set bookmark''':
'''tata bookmark''',
'''[Bookmark reached]''':
'''[Batas bookmark]''',
'''Contents''':
'''Daftar Isi''',
'''No wanted pages in this wiki.''':
'''Tidak ada halaman yang diminta dalam wiki ini.''',
'''Invalid include arguments "%s"!''':
'''Argumen penyertaan tidak benar "%s"!''',
'''Nothing found for "%s"!''':
'''Tak ditemukan apapun untuk "%s"!''',
'''Markup''':
'''Markup''',
'''Display''':
'''Tampilan''',
'''Filename''':
'''Nama berkas''',
'''Rendering of reStructured text is not possible, please install docutils.''':
'''Tidak bisa me-render teks reStructured, silakan instal docutils.''',
'''**Maximum number of allowed includes exceeded**''':
'''**Jumlah maksimum dari penyertaan yang diizinkan terlampaui**''',
'''**Could not find the referenced page: %s**''':
'''**Tidak dapat menemukan halaman referensi: %s**''',
'''Expected "%(wanted)s" after "%(key)s", got "%(token)s"''':
'''Diharapkan "%(wanted)s" setelah "%(key)s", didapat "%(token)s"''',
'''Expected an integer "%(key)s" before "%(token)s"''':
'''Diharapkan integer "%(key)s" sebelum "%(token)s"''',
'''Expected an integer "%(arg)s" after "%(key)s"''':
'''Diharapkan integer "%(arg)s" setelah "%(key)s"''',
'''Expected a color value "%(arg)s" after "%(key)s"''':
'''Diharapkan nilai warna "%(arg)s" setelah "%(key)s"''',
'''XSLT option disabled, please look at HelpOnConfiguration.''':
'''Opsi XSLT dilumpuhkan, silakan lihat pada BantuanPadaKonfigurasi.''',
'''XSLT processing is not available, please install 4suite 1.x.''':
'''Pengolah XSLT tidak tersedia, silakan instal 4suite 1.x.''',
'''%(errortype)s processing error''':
'''%(errortype)s kesalahan pengolahan''',
'''Views/day''':
'''Tilik/hari''',
'''Edits/day''':
'''Sunting/hari''',
'''%(chart_title)s for %(filterpage)s''':
'''%(chart_title)s untuk %(filterpage)s''',
'''green=view
red=edit''':
'''hijau=tilik
merah=sunting''',
'''date''':
'''tanggal''',
'''# of hits''':
'''# pengunjung''',
'''Page Size Distribution''':
'''Distribusi Besar Halaman''',
'''page size upper bound [bytes]''':
'''batas atas besar halaman [bita]''',
'''# of pages of this size''':
'''# halaman dengan ukuran ini''',
'''User agent''':
'''Perantara pengguna''',
'''Others''':
'''Lain-lain''',
'''Distribution of User-Agent Types''':
'''Distribusi dari Tipe Perantara-Pengguna''',
'''Unsubscribe''':
'''Batal berlangganan''',
'''Home''':
'''Pangkal''',
'''[RSS]''':
'''[RSS]''',
'''[DELETED]''':
'''[HAPUS]''',
'''[UPDATED]''':
'''[MUTAKHIR]''',
'''[NEW]''':
'''[BARU]''',
'''[DIFF]''':
'''[PERBEDAAN]''',
'''[BOTTOM]''':
'''[DASAR]''',
'''[TOP]''':
'''[ATAS]''',
'''Click to do a full-text search for this title''':
'''Klik untuk melakukan pencarian teks penuh untuk judul ini''',
'''Preferences''':
'''Preferensi''',
'''Logout''':
'''Keluar''',
'''Clear message''':
'''Bersihkan pesan''',
'''last edited %(time)s by %(editor)s''':
'''terakhir disunting %(time)s oleh %(editor)s''',
'''last modified %(time)s''':
'''terakhir diubah %(time)s''',
'''Search:''':
'''Cari:''',
'''Text''':
'''Teks''',
'''Titles''':
'''Judul''',
'''Search''':
'''Cari''',
'''More Actions:''':
'''Lebih Banyak Aksi:''',
'''------------''':
'''------------''',
'''Raw Text''':
'''Teks Mentah''',
'''Delete Cache''':
'''Hapus Cache''',
'''Delete Page''':
'''Hapus Halaman''',
'''Like Pages''':
'''Halaman Serupa''',
'''Local Site Map''':
'''Site Map Lokal''',
'''My Pages''':
'''Halaman Saya''',
'''Subscribe User''':
'''Daftar Pelanggan''',
'''Remove Spam''':
'''Hapus Spam''',
'''Package Pages''':
'''Halaman Paket''',
'''Render as Docbook''':
'''Buat Docbook''',
'''Do''':
'''Lakukan''',
'''Edit (Text)''':
'''Sunting (Teks)''',
'''Edit (GUI)''':
'''Sunting (GUI)''',
'''Immutable Page''':
'''Halaman Kekal''',
'''Remove Link''':
'''Hapus Taut''',
'''Add Link''':
'''Tambah Taut''',
'''Attachments''':
'''Lampiran''',
'''Show %s days.''':
'''Tampilan %s hari.''',
'''DeleteCache''':
'''HapusCache''',
'''(cached %s)''':
'''(cache %s)''',
'''Or try one of these actions:''':
'''Atau coba salah satu aksi ini:''',
'''Page''':
'''Halaman''',
'''User''':
'''Pengguna''',
'''Sorry, can not save page because "%(content)s" is not allowed in this wiki.''':
'''Maaf, tidak dapat menyimpan halaman karena "%(content)s" tidak diizinkan di wiki ini.''',
'''Line''':
'''Baris''',
'''Deletions are marked like this.''':
'''Penghapusan ditandai seperti ini.''',
'''Additions are marked like this.''':
'''Penambahan ditandai seperti ini.''',
'''Connection to mailserver \'%(server)s\' failed: %(reason)s''':
'''Koneksi ke server surat \'%(server)s\' gagal: %(reason)s''',
'''Mail not sent''':
'''Surat tak dikirim''',
'''Mail sent OK''':
'''Pengiriman surat Oke''',
}
