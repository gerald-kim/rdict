# -*- coding: utf-8 -*-
# Text translations for Magyar (hu).
# Automatically generated - DO NOT EDIT, edit hu.po instead!
meta = {
  'language': """Magyar""",
  'elanguage': """Hungarian""",
  'maintainer': """jmarton@omikk.bme.hu, arostas@omikk.bme.hu""",
  'encoding': 'utf-8',
  'direction': 'ltr',
  'wikimarkup': True,
}
text = {
'''The backed up content of this page is deprecated and will not be included in search results!''':
'''A lap elmentett tartalma elavult, s ezért nem szerepel majd a keresések eredményében!''',
'''Revision %(rev)d as of %(date)s''':
'''%(rev)d. módosítás, dátum: %(date)s''',
'''Redirected from page "%(page)s"''':
'''A(z) "%(page)s" lapról ideirányítva''',
'''This page redirects to page "%(page)s"''':
'''Ez a lap átirányítódik a(z) "%(page)s" lapra''',
'''~-If you submit this form, the submitted values will be displayed.
To use this form on other pages, insert a
[[BR]][[BR]]\'\'\'{{{    [[Form("%(pagename)s")]]}}}\'\'\'[[BR]][[BR]]
macro call.-~
''':
'''~-Az űrlap elküldésével a benne szereplő értékek megjelennek.
Ha más lapon is kívánja használni az űrlapot illessze be ezt a makrót:
[[BR]][[BR]]\'\'\'{{{    [[Form("%(pagename)s")]]}}}\'\'\'[[BR]][[BR]]
-~
''',
'''Create New Page''':
'''Új lap létrehozása''',
'''You are not allowed to view this page.''':
'''A lap megtekintése nem engedélyezett.''',
'''You are not allowed to edit this page.''':
'''A lap szerkesztése nem engedélyezett.''',
'''Page is immutable!''':
'''A lap nem szerkeszthető!''',
'''Cannot edit old revisions!''':
'''A régi módosításokat nem lehet szerkeszteni!''',
'''The lock you held timed out. Be prepared for editing conflicts!''':
'''A zárolás lejárt. Emiatt szerkesztési ütközésekre számíthat!''',
'''Edit "%(pagename)s"''':
'''A(z) "%(pagename)s" lap szerkesztése''',
'''Preview of "%(pagename)s"''':
'''A(z) "%(pagename)s" lap nézete''',
'''Your edit lock on %(lock_page)s has expired!''':
'''A(z) %(lock_page)s zárolása lejárt!''',
'''Your edit lock on %(lock_page)s will expire in # minutes.''':
'''A(z) %(lock_page)s zárolása # perc múlva lejár.''',
'''Your edit lock on %(lock_page)s will expire in # seconds.''':
'''A(z) %(lock_page)s zárolása # másodperc múlva lejár.''',
'''Someone else deleted this page while you were editing!''':
'''Valaki letörölte ezt a lapot míg Ön szerkesztette!''',
'''Someone else changed this page while you were editing!''':
'''Valaki megváltoztatta ezt a lapot míg Ön szerkesztette!''',
'''Someone else saved this page while you were editing!
Please review the page and save then. Do not save this page as it is!
Have a look at the diff of %(difflink)s to see what has been changed.''':
'''Valaki elmentette ezt a lapot amíg Ön szerkesztette.
Semmiképpen se mentse el így, ahogy van!
Kérjük nézze át a lapot és csak azután mentse el!
A változásokat megtekintheti a(z) %(difflink)s különbségeinek oldalán.''',
'''[Content of new page loaded from %s]''':
'''[Az új lap tartalma a(z) %s mintából töltődött be]''',
'''[Template %s not found]''':
'''[A(z) %s minta nem található]''',
'''[You may not read %s]''':
'''[A(z) %s minta nem olvasható]''',
'''Describe %s here.''':
'''Itt írjon a(z) %s-ról/ről''',
'''Check Spelling''':
'''Helyesírás ellenőrzése''',
'''Save Changes''':
'''Változások mentése''',
'''Cancel''':
'''Visszavonás''',
'''By hitting \'\'\'%(save_button_text)s\'\'\' you put your changes under the %(license_link)s.
If you don\'t want that, hit \'\'\'%(cancel_button_text)s\'\'\' to cancel your changes.''':
'''A \'\'\'%(save_button_text)s\'\'\' gomb megnyomásával a változtatásokra a(z) %(license_link)s lesz érvényes.
Ha nem ezt kívánja, akkor a \'\'\'%(cancel_button_text)s\'\'\' gombot nyomja meg.''',
'''Preview''':
'''Nézet''',
'''Text mode''':
'''Szöveg''',
'''Comment:''':
'''Megjegyzés:''',
'''<No addition>''':
'''<Nincs kiegészítés>''',
'''Add to: %(category)s''':
'''Hozzáadás a %(category)s-hoz''',
'''Trivial change''':
'''Lényegtelen változtatás''',
'''Remove trailing whitespace from each line''':
'''A sorvégi szóközök eltávolítása''',
'''Invalid user name {{{\'%s\'}}}.
Name may contain any Unicode alpha numeric character, with optional one
space between words. Group page name is not allowed.''':
'''Érvénytelen felhasználói név: {{{\'%s\'}}}.
A névben bármilyen Unicode alfanumerikus karakter szerepelhet, opcionálisan
egy szóköz helyezhető a szavak közé. Nem használható viszont a csoportlapok neve.''',
'''You are not allowed to do %s on this page.''':
'''A(z) %s műveletet nem hajthatja végre ezen a lapon.''',
'''Login and try again.''':
'''Lépjen be, majd próbálja újra.''',
'''%(hits)d results out of about %(pages)d pages.''':
'''%(pages)d lapból %(hits)d találat''',
'''%.2f seconds''':
'''%.2f s''',
'''match''':
'''találat''',
'''matches''':
'''találatok''',
'''<unknown>''':
'''<ismeretlen>''',
'''Login Name: %s

Login Password: %s

Login URL: %s/%s?action=login
''':
'''Belépési név: %s 
Belépési jelszó: %s
Belépési URL: %s/%s?action=login
''',
'''Somebody has requested to submit your account data to this email address.

If you lost your password, please use the data below and just enter the
password AS SHOWN into the wiki\'s password form field (use copy and paste
for that).

After successfully logging in, it is of course a good idea to set a new and known password.
''':
'''Valaki kérte, hogy küldjük el az Ön felhasználói adatait erre a címre.

Ha elvesztette a jelszavát kérjük az alábbiakban megadott jelszót írja be PONTOSAN
a jelszó-mezőbe (legcélszerűbb ha bemásolja).

Miután sikeresen belépett kérjük írja át a jelszót!
''',
'''[%(sitename)s] Your wiki account data''':
'''[%(sitename)s] a wiki azonosítójának adata''',
'''This wiki is not enabled for mail processing.
Contact the owner of the wiki, who can enable email.''':
'''A levélküldés nincs beállítva ebben a wikiben. Kérjük lépjen kapcsolatba a wiki rendszergazdájával, aki engedélyezheti a levélküldést!''',
'''Please provide a valid email address!''':
'''Kérjük, hogy érvényes levélcímet adjon meg!''',
'''Found no account matching the given email address \'%(email)s\'!''':
'''Nem találtunk a megadott \'%(email)s\' címhez felhasználói azonosítót!''',
'''Use UserPreferences to change your settings or create an account.''':
'''Használja a FelhasználóiBeállítások\'\'\'\'\'\'at a beállításainak megváltoztatásához, vagy új felhasználói fiók létrehozásához.''',
'''Empty user name. Please enter a user name.''':
'''Üres felhasználónév. Kérjük adja meg a felhasználónevet.''',
'''This user name already belongs to somebody else.''':
'''Ez a felhasználónév már foglalt.''',
'''Passwords don\'t match!''':
'''A jelszavak nem egyeznek!''',
'''Please specify a password!''':
'''Kérjük adja meg a jelszót!''',
'''Please provide your email address. If you lose your login information, you can get it by email.''':
'''Kérjük adja meg az email címét. Erre a címre küldjük el majd a belépéshez szükséges adatait amennyiben elvesztené azokat.''',
'''This email already belongs to somebody else.''':
'''Ezt a levélcímet már más bejegyezte.''',
'''User account created! You can use this account to login now...''':
'''Felhasználói fiók létrejött! Ezt a fiókot lehet használni mostantól a belépésre...''',
'''Use UserPreferences to change settings of the selected user account''':
'''Használja a FelhasználóiBeállítások\'\'\'\'\'\'at a kiválasztott felhasználói fiók beállításának megváltoztatásához''',
'''The theme \'%(theme_name)s\' could not be loaded!''':
'''A(z) \'%(theme_name)s\' nevű témát nem lehet betölteni!''',
'''User preferences saved!''':
'''A felhasználói beállításokat elmentettük!''',
'''Default''':
'''Alapértelmezés''',
'''<Browser setting>''':
'''<Böngésző beállításai>''',
'''the one preferred''':
'''az elsődleges''',
'''free choice''':
'''szabad választású''',
'''Select User''':
'''Kiválasztott felhasználó''',
'''Save''':
'''Mentés''',
'''Preferred theme''':
'''Kedvenc téma''',
'''Editor Preference''':
'''Szerkesztő Beállítások''',
'''Editor shown on UI''':
'''Mutatott szerkesztő''',
'''Time zone''':
'''Időzóna''',
'''Your time is''':
'''Az Ön ideje''',
'''Server time is''':
'''A kiszolgáló ideje''',
'''Date format''':
'''Dátumformátum''',
'''Preferred language''':
'''Kedvenc nyelv''',
'''General options''':
'''Általános opciók''',
'''Quick links''':
'''Gyorskapcsok (-linkek)''',
'''This list does not work, unless you have entered a valid email address!''':
'''Ez a lista csak akkor működik, ha megadta a levélcímét!''',
'''Subscribed wiki pages (one regex per line)''':
'''Az előfizetett wiki-lapok (soronként egy reguláris kifejezés)''',
'''Create Profile''':
'''Profil létrehozása''',
'''Mail me my account data''':
'''Kérem a felhasználói adataim elküldését levélben''',
'''Email''':
'''E-levél''',
'''To create an account or recover a lost password, see the %(userprefslink)s page.''':
'''Felhasználói fiók létrehozásához, vagy egy elveszett jelszó helyreállításához lásd a(z) %(userprefslink)s oldalt.''',
'''Name''':
'''Név''',
'''Password''':
'''Jelszó''',
'''Login''':
'''Belépés''',
'''Action''':
'''Művelet''',
'''Required attribute "%(attrname)s" missing''':
'''A(z) "%(attrname)s" kötelező attribútum hiányzik''',
'''Submitted form data:''':
'''Az elküldött űrlap adatai:''',
'''Search Titles''':
'''Címkeresés''',
'''Display context of search results''':
'''A keresések környezetének megjelenítése''',
'''Case-sensitive searching''':
'''Keresésnél a kis/nagybetű számít''',
'''Search Text''':
'''Szövegkeresés''',
'''Go To Page''':
'''Ugrás a laphoz''',
'''Include system pages''':
'''A rendszerlapok szerepeljenek''',
'''Exclude system pages''':
'''A rendszerlapok ne szerepeljenek''',
'''Plain title index''':
'''Egyszerű címjegyzék''',
'''XML title index''':
'''XML-címjegyzék''',
'''Python Version''':
'''Python változat''',
'''MoinMoin Version''':
'''MoinMoin (MoinMoinLap) változat''',
'''Release %s [Revision %s]''':
'''%s kiadás [%s módosítás]''',
'''4Suite Version''':
'''4Suite változat''',
'''Number of pages''':
'''Lapok száma''',
'''Number of system pages''':
'''Rendszerlapok száma''',
'''Accumulated page sizes''':
'''Összesített lapméretek''',
'''Disk usage of %(data_dir)s/pages/''':
'''%(data_dir)s/pages/-nak a lemezhasználtsága''',
'''Disk usage of %(data_dir)s/''':
'''%(data_dir)s/-nak a lemezhasználtsága''',
'''Entries in edit log''':
'''Bejegyzések a szerkesztési naplóban''',
'''NONE''':
'''NINCS''',
'''Global extension macros''':
'''Globális kiterjesztőmakrók''',
'''Local extension macros''':
'''Lokális kiterjesztőmakrók''',
'''Global extension actions''':
'''Globális kiterjesztőműveletek''',
'''Local extension actions''':
'''Lokális kiterjesztőműveletek''',
'''Global parsers''':
'''Telepített pásztázók''',
'''Local extension parsers''':
'''Lokális kiterjesztőmakrók''',
'''Installed processors (DEPRECATED -- use Parsers instead)''':
'''Telepített processzorok (ELAVULTAK -- használjon inkább pásztázókat)''',
'''Disabled''':
'''Kikapcsolt''',
'''Enabled''':
'''Bekapcsolt''',
'''Lupy search''':
'''Lupy keresés''',
'''Active threads''':
'''Aktív szálak''',
'''Please use a more selective search term instead of {{{"%s"}}}''':
'''Kérjük a(z) {{{"%s"}}} helyett használjon szelektívebb kifejezést!''',
'''ERROR in regex \'%s\'''':
'''HIBA a(z) \'%s\' reguláris kifejezésben''',
'''Bad timestamp \'%s\'''':
'''Rossz időbélyeg: \'%s\'''',
'''Expected "=" to follow "%(token)s"''':
'''A(z) "%(token)s" után "=" kell''',
'''Expected a value for key "%(token)s"''':
'''A(z) "%(token)s" értéke hiányzik''',
'''Wiki Markup''':
'''Wiki-jelölés''',
'''Print View''':
'''Nyomtatási nézet''',
'''Your changes are not saved!''':
'''A változtatások nem lettek elmentve!''',
'''Page name is too long, try shorter name.''':
'''A lap neve től hosszú, kérjük adjon meg egy rövidebbet!''',
'''GUI Mode''':
'''GUI mód''',
'''Edit was cancelled.''':
'''A szerkesztés visszavonva.''',
'''You can\'t rename to an empty pagename.''':
'''Nem nevezheti át egy üres lap nevére.''',
'''\'\'\'A page with the name {{{\'%s\'}}} already exists.\'\'\'

Try a different name.''':
'''A(z) {{{\'%s\'}}} nevű lap már létezik!

Próbáljon más nevet adni a lapnak.''',
'''Could not rename page because of file system error: %s.''':
'''Állományrendszer-hiba (%s) miatt nem sikerült az átnevezés.''',
'''Thank you for your changes. Your attention to detail is appreciated.''':
'''Köszönjük, hogy változtatásaival hozzájárult a lap tökéletesítéséhez.''',
'''Page "%s" was successfully deleted!''':
'''A(z) "%s" lap törölve!''',
'''Dear Wiki user,

You have subscribed to a wiki page or wiki category on "%(sitename)s" for change notification.

The following page has been changed by %(editor)s:
%(pagelink)s

''':
'''Kedves Wiki-felhasználó!

Ön a(z) "%(sitename)s" kiszolgálón előfizetett egy wikilap vagy -kategória változásának követésére.
A megváltozott lap: %(pagelink)s, amit %(editor)s szerkesztett.
''',
'''The comment on the change is:
%(comment)s

''':
'''A változtatáshoz fűzött megjegyzés:
%(comment)s

''',
'''New page:
''':
'''Új lap:
''',
'''No differences found!
''':
'''Nics különbség!
''',
'''[%(sitename)s] %(trivial)sUpdate of "%(pagename)s" by %(username)s''':
'''[%(sitename)s] %(trivial)sváltoztatás a(z) "%(pagename)s" lapon, szerzője: %(username)s''',
'''Trivial ''':
'''lényegtelen ''',
'''Status of sending notification mails:''':
'''Az értesítő levelek küldésének állapota:''',
'''[%(lang)s] %(recipients)s: %(status)s''':
'''[%(lang)s] %(recipients)s: %(status)s''',
'''## backup of page "%(pagename)s" submitted %(date)s''':
'''## a(z) "%(pagename)s" lap mentése elküldve, dátum: %(date)s''',
'''Page could not get locked. Unexpected error (errno=%d).''':
'''A lapot nem lehetett zárolni. Váratlan hiba (errno=%d).''',
'''Page could not get locked. Missing \'current\' file?''':
'''A lapot nem lehetett zárolni. Hiányzik a \'current\' nevű állomány?''',
'''You are not allowed to edit this page!''':
'''Nem szerkesztheti ezt a lapot!''',
'''You cannot save empty pages.''':
'''Nem menthet el üres lapot.''',
'''You already saved this page!''':
'''Már mentette ezt az oldalt!''',
'''Sorry, someone else saved the page while you edited it.

Please do the following: Use the back button of your browser, and cut&paste
your changes from there. Then go forward to here, and click EditText again.
Now re-add your changes to the current page contents.

\'\'Do not just replace
the content editbox with your version of the page, because that would
delete the changes of the other person, which is excessively rude!\'\'
''':
'''Sajnos valaki más elmentette a lapot míg Ön szerkesztette.

Kérjük a böngészője "vissza"-gombjával lépjen vissza, majd vágja ki a megváltozott szöveget onnan. Ezután térjen vissza ide, majd kattintson a SzövegSzerkesztés-re ismét, s illessze be a kivágott szöveget a az aktuális lapba.

\'\'Ne cserélje le egyszerűen a megváltozott szöveget az Önével, mert ezzel elveszne a másik felhasználó által beírt szöveg! Udvariatlanságnak számít más szövegét így eltüntetni.\'\'
''',
'''A backup of your changes is [%(backup_url)s here].''':
'''Az Ön változtatásainak mentése [%(backup_url)s itt] található.''',
'''You did not change the page content, not saved!''':
'''Nem változtatta meg a lapot, ezért nem is mentettük el!''',
'''You can\'t change ACLs on this page since you have no admin rights on it!''':
'''Nem változtathatja meg a lap ACL-jeit, mert Önnek ehhez nincs adminisztrátori joga!''',
'''The lock of %(owner)s timed out %(mins_ago)d minute(s) ago, and you were granted the lock for this page.''':
'''Ön megkapta a zárolást erre a lapra, mert a(z) %(owner)s zárolása lejárt %(mins_ago)d perce.''',
'''Other users will be \'\'blocked\'\' from editing this page until %(bumptime)s.''':
'''A többi felhasználó \'\'kizárva\'\' a lap szerkesztéséből %(bumptime)s-ig.''',
'''Other users will be \'\'warned\'\' until %(bumptime)s that you are editing this page.''':
'''A többi felhasználó \'\'figyelmeztetést\'\' kap %(bumptime)s-ig, hogy Ön szerkeszti ezt a lapot.''',
'''Use the Preview button to extend the locking period.''':
'''A Nézet gombra kattintva meghosszabbíthatja a zárolás idejét.''',
'''This page is currently \'\'locked\'\' for editing by %(owner)s until %(timestamp)s, i.e. for %(mins_valid)d minute(s).''':
'''A lapot %(owner)s \'\'zárolta\'\' %(timestamp)s-ig, azaz még %(mins_valid)d percig.''',
'''This page was opened for editing or last previewed at %(timestamp)s by %(owner)s.[[BR]]
\'\'\'You should \'\'refrain from editing\'\' this page for at least another %(mins_valid)d minute(s),
to avoid editing conflicts.\'\'\'[[BR]]
To leave the editor, press the Cancel button.''':
'''Ezt a lapot %(owner)s %(timestamp)s-kor nyitotta meg vagy ekkor választotta ki a Nézetet utoljára.[[BR]]
\'\'\'Ha el szeretné kerülni a szerkesztői ütközéseket \'\'ne szerkessze\'\' ezt az oldalt legalább még %(mins_valid)d percig!\'\'\'A szerkesztő elhagyásához nyomja meg a Visszavonás gombot.''',
'''The package needs a newer version of MoinMoin (at least %s).''':
'''A csomaghoz újabb (legalább %s) verziójú MoinMoin\'\'\'\'\'\'ra van szükség.''',
'''The theme name is not set.''':
'''A téma neve nincs beállítva.''',
'''Installing theme files is only supported for standalone type servers.''':
'''A téma-fájlok telepítése csak a standalone típusú szervereknél támogatott.''',
'''Installation of \'%(filename)s\' failed.''':
'''A(z) \'%(filename)s\' telepítése sikertelen.''',
'''The file %s is not a MoinMoin package file.''':
'''A(z) %s fájl nem egy MoinMoin csomag része.''',
'''The page %s does not exist.''':
'''A(z) %s oldal nem létezik!''',
'''Invalid package file header.''':
'''Érvénytelen a csomagfájl feje.''',
'''Package file format unsupported.''':
'''Csomagfájl formátum nem támogatott.''',
'''Unknown function %(func)s in line %(lineno)i.''':
'''Ismeretlen függvény %(func)s a(z) %(lineno)i. sorban.''',
'''The file %s was not found in the package.''':
'''A fájl %s nem található a csomagban.''',
''' Emphasis:: [[Verbatim(\'\')]]\'\'italics\'\'[[Verbatim(\'\')]]; [[Verbatim(\'\'\')]]\'\'\'bold\'\'\'[[Verbatim(\'\'\')]]; [[Verbatim(\'\'\'\'\')]]\'\'\'\'\'bold italics\'\'\'\'\'[[Verbatim(\'\'\'\'\')]]; [[Verbatim(\'\')]]\'\'mixed \'\'[[Verbatim(\'\'\')]]\'\'\'\'\'bold\'\'\'[[Verbatim(\'\'\')]] and italics\'\'[[Verbatim(\'\')]]; [[Verbatim(----)]] horizontal rule.
 Headings:: [[Verbatim(=)]] Title 1 [[Verbatim(=)]]; [[Verbatim(==)]] Title 2 [[Verbatim(==)]]; [[Verbatim(===)]] Title 3 [[Verbatim(===)]];   [[Verbatim(====)]] Title 4 [[Verbatim(====)]]; [[Verbatim(=====)]] Title 5 [[Verbatim(=====)]].
 Lists:: space and one of: * bullets; 1., a., A., i., I. numbered items; 1.#n start numbering at n; space alone indents.
 Links:: [[Verbatim(JoinCapitalizedWords)]]; [[Verbatim(["brackets and double quotes"])]]; url; [url]; [url label].
 Tables:: || cell text |||| cell text spanning 2 columns ||;    no trailing white space allowed after tables or titles.

(!) For more help, see HelpOnEditing or SyntaxReference.
''':
''' Kiemelés:: [[Verbatim(\'\')]]\'\'kurzív\'\'[[Verbatim(\'\')]]; [[Verbatim(\'\'\')]]\'\'\'félkövér\'\'\'[[Verbatim(\'\'\')]]; [[Verbatim(\'\'\'\'\')]]\'\'\'\'\'félkövér kurzív\'\'\'\'\'[[Verbatim(\'\'\'\'\')]]; [[Verbatim(\'\')]]\'\'vegyes \'\'[[Verbatim(\'\'\')]]\'\'\'\'\'félkövér\'\'\'[[Verbatim(\'\'\')]] és kurzív\'\'[[Verbatim(\'\')]]; [[Verbatim(----)]] vízszintes vonal.
 Címek:: [[Verbatim(=)]] 1. szintű cím [[Verbatim(=)]]; [[Verbatim(==)]] 2. szintű cím [[Verbatim(==)]]; [[Verbatim(===)]] 3. szintű cím [[Verbatim(===)]];   [[Verbatim(====)]] 4. szintű cím [[Verbatim(====)]]; [[Verbatim(=====)]] 5. szintű cím [[Verbatim(=====)]].
 Listák:: szóköz és egy: * bütykök (körök és négyzetek); 1., a., A., i., I. sorszámozott elemek; 1.#n a sorszámozás n-nél kezdődik; a szóköz magában beljebb tolja a szöveget.
 Kapcsok (linkek):: [[Verbatim(NagyKezdőbetűsSzavakEgybeírva)]]; [[Verbatim(["szögletes zárójelek és macskakörmök"])]]; URL; [URL]; [URL címke].
 Táblázatok:: || cella |||| két oszlopot átfogó cella ||;    cím és táblázat esetén nem szabad szóközt tenni a sor végére.

(!) További segítségért olvassa el a HelpOnEditing vagy a SzerkesztésiSegédlet oldalt.
''',
'''Diffs''':
'''Különbségek''',
'''Info''':
'''Infó''',
'''Edit''':
'''Szerkesztés''',
'''UnSubscribe''':
'''Leiratkozás''',
'''Subscribe''':
'''Előfizetés''',
'''Raw''':
'''Nyers''',
'''XML''':
'''XML''',
'''Print''':
'''Nyomtatás''',
'''View''':
'''Nézet''',
'''Up''':
'''Fel''',
'''Publish my email (not my wiki homepage) in author info''':
'''Az email címem közzététele (a wiki felhasználói oldalam helyett) a szerkesztői információkban''',
'''Open editor on double click''':
'''Kettős kattintásra nyíljon meg a szerkesztő''',
'''Jump to last visited page instead of frontpage''':
'''Ugorj a legutoljára látogatott oldalra a kezdőoldal helyett''',
'''Show question mark for non-existing pagelinks''':
'''A nemlétező kapcsoknál (linkeknél) kérdőjel megjelenítése''',
'''Show page trail''':
'''Lapnyomok megjelenítése''',
'''Show icon toolbar''':
'''Ikon-eszközsáv megjelenítése''',
'''Show top/bottom links in headings''':
'''Felülre/alulra mutató kapcsok (linkek) megjelenítése a címeknél''',
'''Show fancy diffs''':
'''A különbségek díszes megjelenítése''',
'''Add spaces to displayed wiki names''':
'''Szóközök hozzáadása a wiki-nevekhez''',
'''Remember login information''':
'''A belépési adatok megjegyzése''',
'''Subscribe to trivial changes''':
'''Előfizetés a lényegtelen változásokra''',
'''Disable this account forever''':
'''Tiltsuk le ezt a felhasználói azonosítót örökre''',
'''(Use Firstname\'\'\'\'\'\'Lastname)''':
'''(Használja a Vezetéknév\'\'\'\'\'\'Keresztnév formát)''',
'''Alias-Name''':
'''Álnév''',
'''Password repeat''':
'''Jelszó mégegyszer''',
'''(Only when changing passwords)''':
'''(Csak jelszóváltoztatásnál)''',
'''User CSS URL''':
'''A felhasználói CSS URL-je''',
'''(Leave it empty for disabling user CSS)''':
'''(A felhasználói CSS letiltásához hagyja üresen)''',
'''Editor size''':
'''Szerkesztő mérete''',
'''No older revisions available!''':
'''Nincsenek régebbi módosítások!''',
'''Diff for "%s"''':
'''A(z) "%s" különbségei''',
'''Differences between revisions %d and %d''':
'''A(z) %d. és a(z) %d. módosítás különbségei''',
'''(spanning %d versions)''':
'''(%d változatot fog át)''',
'''No differences found!''':
'''Nincsenek különbségek!''',
'''The page was saved %(count)d times, though!''':
'''Bár a lap %(count)d példányban van elmentve!''',
'''(ignoring whitespace)''':
'''(a szóközöket figyelmen kívül hagytuk)''',
'''Ignore changes in the amount of whitespace''':
'''A szóközmennyiség változásának figyelmen kívül hagyása''',
'''General Information''':
'''Általános információk''',
'''Page size: %d''':
'''Lapméret: %d''',
'''SHA digest of this page\'s content is:''':
'''A lap tartalmának SHA-kivonata:''',
'''The following users subscribed to this page:''':
'''A felhasználók, akik előfizettek erre a lapra:''',
'''This page links to the following pages:''':
'''Ez a lap a következő lapokhoz kacsolódik:''',
'''Date''':
'''Dátum''',
'''Size''':
'''Méret''',
'''Diff''':
'''Különbségek''',
'''Editor''':
'''Szerkesztő''',
'''Comment''':
'''Megjegyzés''',
'''view''':
'''nézet''',
'''raw''':
'''nyers''',
'''print''':
'''nyomtatás''',
'''revert''':
'''visszaállás''',
'''Revert to revision %(rev)d.''':
'''A(z) %(rev)d. módosításra való visszaállás.''',
'''edit''':
'''szerkesztés''',
'''get''':
'''letöltés''',
'''del''':
'''törlés''',
'''N/A''':
'''Nincs adat''',
'''Revision History''':
'''Módosítások története''',
'''No log entries found.''':
'''A napló üres.''',
'''Info for "%s"''':
'''Információk "%s"-ról/ről''',
'''Show "%(title)s"''':
'''"%(title)s" megjelenítése''',
'''General Page Infos''':
'''Általános lapinformációk''',
'''Show chart "%(title)s"''':
'''A(z) "%(title)s" grafikon megjelenítése''',
'''Page hits and edits''':
'''A lap találatainak és szerkesztéseinek száma''',
'''You are not allowed to revert this page!''':
'''Nem állíthatja vissza ezt a lapot!''',
'''You must login to add a quicklink.''':
'''Be kell lépnie a gyorslinkek hozzáadásához.''',
'''Your quicklink to this page has been removed.''':
'''Az Ön gyorslinkje erre az oldalra el lett távolítva.''',
'''A quicklink to this page has been added for you.''':
'''Egy erre az oldalra mutató gyorslink került hozzáadásra.''',
'''You are not allowed to subscribe to a page you can\'t read.''':
'''Nem fizethet elő olyan lapra, amelyet nem olvashat.''',
'''This wiki is not enabled for mail processing.''':
'''A levélküldés nincs bekapcsolva ebben a wikiben. Kérjük lépjen kapcsolatba a wiki rendszergazdájával, aki engedélyezheti a levélküldést!''',
'''You must log in to use subscribtions.''':
'''Be kell lépnie a feliratkozások használatához.''',
'''Add your email address in your UserPreferences to use subscriptions.''':
'''Adja meg az email címét az Ön FelhasználóiBeállítások oldalán a feliratkozások használatához.''',
'''Your subscribtion to this page has been removed.''':
'''Erre a lapra megszűnt az előfizetése.''',
'''Can\'t remove regular expression subscription!''':
'''A reguláris kifejezéses előfizetést nem lehet lemondani!''',
'''Edit the subscription regular expressions in your UserPreferences.''':
'''Szerkessze a feliratkozásokhoz a reguláris kifejezéseket a FelhasználóiBeállítások\'\'\'\'\'\'ban.''',
'''You have been subscribed to this page.''':
'''Ön előfizetett erre a lapra.''',
'''Charts are not available!''':
'''A diagramok nem elérhetőek!''',
'''You need to provide a chart type!''':
'''Meg kell adnia a diagram típusát!''',
'''Bad chart type "%s"!''':
'''Hibás diagramtípus: "%s"''',
'''This page is already deleted or was never created!''':
'''Ezt a lapot már törölték, vagy soha nem is hozták létre!''',
'''No pages like "%s"!''':
'''A(z) "%s" laphoz nincs hasonló!''',
'''Invalid filename "%s"!''':
'''Érvénytelen fájlnév: "%s"''',
'''Attachment \'%(target)s\' (remote name \'%(filename)s\') already exists.''':
'''A(z) \'%(target)s\' (a távoli neve \'%(filename)s\') melléklet már létezik.''',
'''Created the package %s containing the pages %s.''':
'''%s nevű csomag, mely tartalmazza a(z) %s oldalakat, létre lett hozva.''',
'''Package pages''':
'''Oldalak csomagolása''',
'''Package name''':
'''Csomag neve''',
'''List of page names - separated by a comma''':
'''Az oldalnevek listája - vesszőkkel elválasztva. (csv)''',
'''Unknown user name: {{{"%s"}}}. Please enter user name and password.''':
'''Ismeretlen felhasználónév: {{{"%s"}}}. Kérjük adja meg a felhasználónevet és a jelszót.''',
'''Missing password. Please enter user name and password.''':
'''Hiányzik a jelszó. Kérjük adja meg a felhasználónevet és a jelszót.''',
'''Sorry, wrong password.''':
'''Sajnos rossz a jelszó.''',
'''Exactly one page like "%s" found, redirecting to page.''':
'''Pontosan egy hasonló lap van a(z) "%s" laphoz, átirányítva oda.''',
'''Pages like "%s"''':
'''A(z) "%s" laphoz hasonlóak''',
'''%(matchcount)d %(matches)s for "%(title)s"''':
'''%(matchcount)d %(matches)s a(z) "%(title)s" mintához''',
'''Local Site Map for "%s"''':
'''Helyi térkép a(z) "%s" laphoz''',
'''Please log in first.''':
'''Először be kell jelentkeznie.''',
'''Please first create a homepage before creating additional pages.''':
'''Mielőtt további oldalakat készít kérjük, készítse el a honlapját!''',
'''You can add some additional sub pages to your already existing homepage here.

You can choose how open to other readers or writers those pages shall be,
access is controlled by group membership of the corresponding group page.

Just enter the sub page\'s name and click on the button to create a new page.

Before creating access protected pages, make sure the corresponding group page
exists and has the appropriate members in it. Use HomepageGroupsTemplate for creating
the group pages.

||\'\'\'Add a new personal page:\'\'\'||\'\'\'Related access control list group:\'\'\'||
||[[NewPage(HomepageReadWritePageTemplate,read-write page,%(username)s)]]||["%(username)s/ReadWriteGroup"]||
||[[NewPage(HomepageReadPageTemplate,read-only page,%(username)s)]]||["%(username)s/ReadGroup"]||
||[[NewPage(HomepagePrivatePageTemplate,private page,%(username)s)]]||%(username)s only||

''':
'''Itt további lapokat adhat a már létező honlapjához.

Megválaszthatja, hogy a lapok írását és olvasását kinek engedélyezi. A hozzáférést a megfelelő csoport-lapokkal szabályozhatja.

Csak írja be az új al-oldal nevét és kattintson a gombra a létrehozáshoz.

Mielőtt hozzáférés-szabályozással ellátott oldalt készít, bizonyosodjon meg a megfelelő csoport-oldal létezéséről, és arról, hogy a tartalma megfelelő. A csoport-oldal elkészítéséhez használja a HomepageGroupsTemplate sablont.

||\'\'\'Személyes oldal hozzáadása:\'\'\'||\'\'\'Kapcsolódó hozzáférés-szabályozási csoport:\'\'\'||
||[[NewPage(HomepageReadWritePageTemplate,írható/olvasható oldal,%(username)s)]]||["%(username)s/ReadWriteGroup"]||
||[[NewPage(HomepageReadPageTemplate,csak olvasható oldal,%(username)s)]]||["%(username)s/ReadGroup"]||
||[[NewPage(HomepagePrivatePageTemplate,privát oldal,%(username)s)]]||kizárólag %(username)s||

''',
'''MyPages management''':
'''Saját (személyes) lapok kezelése''',
'''Rename Page''':
'''Lap átnevezése''',
'''New name''':
'''Új név''',
'''Optional reason for the renaming''':
'''Az átnevezés indoka (nem kötelező kitölteni)''',
'''(including %(localwords)d %(pagelink)s)''':
'''(beleértve %(localwords)d szót a(z) %(pagelink)s lapról)''',
'''The following %(badwords)d words could not be found in the dictionary of %(totalwords)d words%(localwords)s and are highlighted below:''':
'''A következő %(badwords)d szót nem lehet megtalálni a(z) %(totalwords)d szót tartalmazó szótárból%(localwords)s. Ezek a szavak kiemelve szerepelnek a lapon:''',
'''Add checked words to dictionary''':
'''A bejelölt szavak hozzáadása a szótárhoz''',
'''No spelling errors found!''':
'''Nem találtunk helyesírási hibát.''',
'''You can\'t check spelling on a page you can\'t read.''':
'''Nem ellenőrizheti a helyesírást olyan lapon, amelyet nem olvashat.''',
'''Do it.''':
'''Végrahajtás.''',
'''Execute action %(actionname)s?''':
'''Végrehajtja a %(actionname)s műveletet?''',
'''Action %(actionname)s is excluded in this wiki!''':
'''A(z) %(actionname)s művelet kizárt ebben a wikiben.''',
'''You are not allowed to use action %(actionname)s on this page!''':
'''Ezen a lapon nem használhatja a %(actionname)s műveletet!''',
'''Please use the interactive user interface to use action %(actionname)s!''':
'''Kérjük, a(z) %(actionname)s művelet végrehajtásához az interaktív felhasználói felületet használja!''',
'''Title Search: "%s"''':
'''Címkeresés, minta: "%s"''',
'''Full Text Search: "%s"''':
'''Keresés a teljes szövegben, minta: "%s"''',
'''Full Link List for "%s"''':
'''Teljes kapocslista (link-lista), minta: "%s"''',
'''Cannot create a new page without a page name.  Please specify a page name.''':
'''Név nélküli lapot nem lehet létrehozni. Kérjük adja meg a lap nevét!''',
'''Select Author''':
'''Szerző kiválasztása''',
'''Revert all!''':
'''Minden visszaállítása''',
'''You are not allowed to use this action.''':
'''Nem használhatja ezt a műveletet.''',
'''Subscribe users to the page %s''':
'''Felhasználók feliratkoztatása a(z) %s oldalra''',
'''Subscribed for %s:''':
'''Feliratkozva a %s-ra/re:''',
'''Not a user:''':
'''Nem felhasználó:''',
'''You are not allowed to perform this action.''':
'''Ezt a műveletet nem hajthatja végre.''',
'''You are now logged out.''':
'''A sütit letöröltük. Ön kilépett.''',
'''Delete''':
'''Törlés''',
'''Optional reason for the deletion''':
'''A törlés indoka (nem kötelező kitölteni)''',
'''Really delete this page?''':
'''Biztosan törölni kívánja ezt a lapot?''',
'''Restored Backup: %(filename)s to target dir: %(targetdir)s.
Files: %(filecount)d, Directories: %(dircount)d''':
'''Visszaállított mentés: %(filename)s célkönyvtár: %(targetdir)s.
Fájlok száma: %(filecount)d, könyvtárak száma: %(dircount)d''',
'''Restoring backup: %(filename)s to target dir: %(targetdir)s failed.''':
'''A %(filename)s mentés visszaállítása a %(targetdir)s könyvtárba sikertelen.''',
'''Wiki Backup / Restore''':
'''Wiki biztonsági mentés / visszaállítás''',
'''Some hints:
 * To restore a backup:
  * Restoring a backup will overwrite existing data, so be careful.
  * Rename it to <siteid>.tar.<compression> (remove the --date--time--UTC stuff).
  * Put the backup file into the backup_storage_dir (use scp, ftp, ...).
  * Hit the [[GetText(Restore)]] button below.

 * To make a backup, just hit the [[GetText(Backup)]] button and save the file
   you get to a secure place.

Please make sure your wiki configuration backup_* values are correct and complete.

''':
'''Néhány jótanács:
 * Biztonsági másolat visszaálltásához:
  * Biztonsági másolat visszaállítása felülírja a meglévő adatokat, tehát csak óvatosan!
  * Nevezd át <oldalazonosító>.tar.<tömörítés> névre (töröld a --date--time--UTC részt).
  * Helyezd a biztonsági másolat fájlt a backup_storage_dir könyvtárba (használj scp, ftp vagy hasonló programot).
  * Kattints a lentebb levő [[GetText(Restore)]] gombra.

 * Biztonsági másolat készítéséhez kattints a [[GetText(Backup)]] gombra és mentsd a fájlt biztonságos helyre.

Győződj meg arról, hogy a wiki beállításaiban a backup_* beállítások helyesek és teljesek.

''',
'''Backup''':
'''Biztonsági másolat készítése''',
'''Restore''':
'''Visszaállít''',
'''You are not allowed to do remote backup.''':
'''Nem készíthet távoli biztonsági másolatot (backup).''',
'''Unknown backup subaction: %s.''':
'''Érvénytelen biztonsági mentési mód: %s.''',
'''[%d attachments]''':
'''[%d melléklet]''',
'''There are <a href="%(link)s">%(count)s attachment(s)</a> stored for this page.''':
'''Ehhez a laphoz <a href="%(link)s">%(count)s melléklet</a> tartozik.''',
'''Filename of attachment not specified!''':
'''A melléklet nevét nem adta meg!''',
'''Attachment \'%(filename)s\' does not exist!''':
'''A(z) \'%(filename)s\' melléklet nem létezik!''',
'''To refer to attachments on a page, use \'\'\'{{{attachment:filename}}}\'\'\', 
as shown below in the list of files. 
Do \'\'\'NOT\'\'\' use the URL of the {{{[get]}}} link, 
since this is subject to change and can break easily.''':
'''A mellékletre az \'\'\'{{{attachment:filename}}}\'\'\' formában lehet hivatkozni, 
ahogy ez a mellékletek listáján látszik. 
Kérjük \'\'\'NE\'\'\' használja a {{{[letöltés]}}} URL-jét, 
mert ez megváltozhat, és akkor már nem lesz érvényes a kapocs (link).''',
'''unzip''':
'''kicsomagol''',
'''install''':
'''telepít''',
'''No attachments stored for %(pagename)s''':
'''A(z) %(pagename)s laphoz nem tartozik melléklet''',
'''Edit drawing''':
'''Rajz szerkesztése''',
'''Attached Files''':
'''Mellékletek''',
'''You are not allowed to attach a file to this page.''':
'''Ehhez a laphoz nem csatolhat mellékletet.''',
'''New Attachment''':
'''Új melléklet''',
'''An upload will never overwrite an existing file. If there is a name
conflict, you have to rename the file that you want to upload.
Otherwise, if "Rename to" is left blank, the original filename will be used.''':
'''A föltöltés sohasem ír fölül egy létező mellékletet. Amennyiben egy meglévő melléklet nevét viselő állományt töltenénk föl az új mellékletet csak egy másik néven menthetjük el. Az új nevet a "Mentés más néven" mezőben adhatjuk meg.''',
'''File to upload''':
'''A föltöltendő állomány''',
'''Rename to''':
'''Átnevezés''',
'''Upload''':
'''Feltöltés''',
'''File attachments are not allowed in this wiki!''':
'''Mellékletek nem engedélyezettek ebben a wikiben!''',
'''You are not allowed to save a drawing on this page.''':
'''A rajz elmentése nem engedélyezett ezen a lapon.''',
'''No file content. Delete non ASCII characters from the file name and try again.''':
'''Hibás az állománynév. Kérjük törölje a nem-ASCII karaktereket az állománynévből, és próbálja újra.''',
'''You are not allowed to delete attachments on this page.''':
'''A mellékletek törlése nem engedélyezett ezen a lapon.''',
'''You are not allowed to get attachments from this page.''':
'''A mellékletek letöltése nem engedélyezett erről a lapról.''',
'''You are not allowed to unzip attachments of this page.''':
'''Az oldal mellékleteinek kicsomagolása nem engedélyezett.''',
'''You are not allowed to install files.''':
'''Fájlok telepítése nem engedélyezett.''',
'''You are not allowed to view attachments of this page.''':
'''A mellékletek megtekintése nem engedélyezett ennél a lapnál.''',
'''Unsupported upload action: %s''':
'''Nem támogatott föltöltési művelet: %s''',
'''Attachments for "%(pagename)s"''':
'''A(z) "%(pagename)s" lap mellékletei''',
'''Attachment \'%(target)s\' (remote name \'%(filename)s\') with %(bytes)d bytes saved.''':
'''A(z) \'%(target)s\' (a távoli neve \'%(filename)s\') melléklet elmentve, hossza %(bytes)d byte''',
'''Attachment \'%(filename)s\' deleted.''':
'''A(z) \'%(filename)s\' melléklet törölve.''',
'''Attachment \'%(filename)s\' installed.''':
'''A(z) \'%(filename)s\' melléklet telepítve.''',
'''Attachment \'%(filename)s\' could not be unzipped because the resulting files would be too large (%(space)d kB missing).''':
'''A(z) \'%(filename)s\' mellékletet nem lehet kicsomagolni, mert a keletkező fájlok mérete túl nagy lenne (%(space)d kB hiányzik).''',
'''Attachment \'%(filename)s\' could not be unzipped because the resulting files would be too many (%(count)d missing).''':
'''A(z) \'%(filename)s\' mellékletet nem lehet kicsomagolni, mert túl sok fájl keletkezne (%(count)d hiányzik).''',
'''Attachment \'%(filename)s\' unzipped.''':
'''A(z) \'%(filename)s\' melléklet kicsomagolása megtörtént.''',
'''Attachment \'%(filename)s\' not unzipped because the files are too big, .zip files only, exist already or reside in folders.''':
'''A(z) \'%(filename)s\' melléklet nem lett kicsomagolva, mert a fájlok túl nagyok, csak .zip fájlokat fogad a wiki, a fájlok már léteznek vagy mappába rendezettek.''',
'''The file %(target)s is not a .zip file.''':
'''A %(target)s fájl nem egy .zip állomány.''',
'''Attachment \'%(filename)s\'''':
'''A(z) \'%(filename)s\' melléklet''',
'''Package script:''':
'''Csomagszkript:''',
'''File Name''':
'''Állománynév''',
'''Modified''':
'''Módosítva''',
'''Unknown file type, cannot display this attachment inline.''':
'''Ismeretlen állománytípus: nem lehet beágyazva megjeleníteni.''',
'''attachment:%(filename)s of %(pagename)s''':
'''A(z) %(pagename)s lap melléklete: [[Verbatim(attachment:)]]%(filename)s''',
'''Upload new attachment "%(filename)s"''':
'''A(z) "%(filename)s" melléklet feltöltése''',
'''Create new drawing "%(filename)s"''':
'''"%(filename)s" nevű új rajz készítése''',
'''Edit drawing %(filename)s''':
'''A(z) %(filename)s nevű rajz szerkesztése''',
'''Toggle line numbers''':
'''Sorszámozás megjelenítése/elrejtése''',
'''FrontPage''':
'''KezdőLap''',
'''RecentChanges''':
'''ÚjabbVáltozások''',
'''TitleIndex''':
'''CímJegyzék''',
'''WordIndex''':
'''SzóJegyzék''',
'''FindPage''':
'''KeresőLap''',
'''SiteNavigation''':
'''HelyiNavigáció''',
'''HelpContents''':
'''SegédletTartalomjegyzék''',
'''HelpOnFormatting''':
'''FormázásiSegédlet''',
'''UserPreferences''':
'''FelhasználóiBeállítások''',
'''WikiLicense''':
'''WikiEngedélyek''',
'''MissingPage''':
'''HiányzóLap''',
'''MissingHomePage''':
'''HiányzóHonlap''',
'''Mon''':
'''Hétfő''',
'''Tue''':
'''Kedd''',
'''Wed''':
'''Szerda''',
'''Thu''':
'''Csütörtök''',
'''Fri''':
'''Péntek''',
'''Sat''':
'''Szombat''',
'''Sun''':
'''Vasárnap''',
'''AttachFile''':
'''ÁllományCsatolás''',
'''DeletePage''':
'''LapTörlés''',
'''LikePages''':
'''HasonlóLapok''',
'''LocalSiteMap''':
'''HelyiLaptérkép''',
'''RenamePage''':
'''LapÁtnevezés''',
'''SpellCheck''':
'''HelyesírásEllenőrzés''',
'''Invalid MonthCalendar calparms "%s"!''':
'''Érvénytelen hívási paramétert kapott a MonthCalendar: "%s".''',
'''Invalid MonthCalendar arguments "%s"!''':
'''Érvénytelen MonthCalendar paraméter: "%s"''',
'''Unsupported navigation scheme \'%(scheme)s\'!''':
'''A(z) \'%(scheme)s\' navigációs sémához nincs támogatás!''',
'''No parent page found!''':
'''Nincs szülőlap!''',
'''Wiki''':
'''Wiki''',
'''Slideshow''':
'''Diavetítés''',
'''Start''':
'''Kezdet''',
'''Slide %(pos)d of %(size)d''':
'''%(pos)d. dia, mérete: %(size)d''',
'''No orphaned pages in this wiki.''':
'''Nincs árva lap.''',
'''No quotes on %(pagename)s.''':
'''A(z) %(pagename)s lapon nincs idézet.''',
'''Upload of attachment \'%(filename)s\'.''':
'''A(z) \'%(filename)s\' melléklet föltöltése.''',
'''Drawing \'%(filename)s\' saved.''':
'''A(z) \'%(filename)s\' rajz elmentve.''',
'''%(mins)dm ago''':
'''%(mins)d perccel ezelőtt''',
'''(no bookmark set)''':
'''(nincs könyvjelző)''',
'''(currently set to %s)''':
'''(%s-ra/re állítva)''',
'''Delete Bookmark''':
'''Könyvjelző törlése''',
'''Set bookmark''':
'''Könyvjelző hozzáadása''',
'''set bookmark''':
'''könyvjelző hozzáadása''',
'''[Bookmark reached]''':
'''[Könyvjelző]''',
'''Contents''':
'''Tartalomjegyzék''',
'''No wanted pages in this wiki.''':
'''Ebben a wikiben nincsenek kívánt lapok.''',
'''Invalid include arguments "%s"!''':
'''Érvénytelen include-paraméter: "%s"''',
'''Nothing found for "%s"!''':
'''Nincs találat a(z) "%s" mintához!''',
'''Markup''':
'''Jelölés''',
'''Display''':
'''Megjelenítés''',
'''Filename''':
'''Állománynév''',
'''**Maximum number of allowed includes exceeded**''':
'''Az beágyazott dokumentumok (include-ok) száma több, mint amennyi engedélyezett**''',
'''**Could not find the referenced page: %s**''':
'''**A hivatkozott lap (%s) nem található**''',
'''Expected "%(wanted)s" after "%(key)s", got "%(token)s"''':
'''"%(wanted)s" helyett "%(token)s" szerepel "%(key)s" után''',
'''Expected an integer "%(key)s" before "%(token)s"''':
'''"%(token)s" előtt egész szám kell "%(key)s" helyett''',
'''Expected an integer "%(arg)s" after "%(key)s"''':
'''"%(key)s" után egész szám kell "%(arg)s" helyett''',
'''Expected a color value "%(arg)s" after "%(key)s"''':
'''"%(key)s" után egy színérték kell "%(arg)s" helyett''',
'''XSLT option disabled, please look at HelpOnConfiguration.''':
'''Az XSLT letiltva, lásd a HelpOnConfiguration lapot.''',
'''XSLT processing is not available, please install 4suite 1.x.''':
'''Az XSLT-feldolgozás nem elérhető, kérjük telepítse a 4suite 1.x változatát.''',
'''%(errortype)s processing error''':
'''%(errortype)s - feldolgozási hiba''',
'''Views/day''':
'''Nézet/nap''',
'''Edits/day''':
'''Szerkesztés/nap''',
'''%(chart_title)s for %(filterpage)s''':
'''%(filterpage)s laphoz tartozó %(chart_title)s''',
'''green=view
red=edit''':
'''zöld=megjelenítés
piros=szerkesztés''',
'''date''':
'''dátum''',
'''# of hits''':
'''találatok száma''',
'''Page Size Distribution''':
'''Lapméret-eloszlás''',
'''page size upper bound [bytes]''':
'''lapméret felső korlátja [byte]''',
'''# of pages of this size''':
'''az ilyen méretű lapok száma''',
'''User agent''':
'''kliens-típus (user agent)''',
'''Others''':
'''Mások''',
'''Distribution of User-Agent Types''':
'''A WWW-kliensek eloszlása''',
'''Unsubscribe''':
'''Leiratkozás''',
'''Home''':
'''Kezdőlap''',
'''[RSS]''':
'''[RSS]''',
'''[DELETED]''':
'''[TÖRÖLT]''',
'''[UPDATED]''':
'''[FRISSÍTETT]''',
'''[NEW]''':
'''[ÚJ]''',
'''[DIFF]''':
'''[KÜLÖNBSÉG]''',
'''[BOTTOM]''':
'''[ALULRA]''',
'''[TOP]''':
'''[FELÜLRE]''',
'''Click to do a full-text search for this title''':
'''Kattintson a cím teljes szöveges kereséséért''',
'''Preferences''':
'''Felhasználói beállítások''',
'''Logout''':
'''Kilépés''',
'''Clear message''':
'''Üzenet törlése''',
'''last edited %(time)s by %(editor)s''':
'''Utoljára %(editor)s módosította %(time)s-kor.''',
'''last modified %(time)s''':
'''Utoljára módosítva: %(time)s''',
'''Search:''':
'''Keresés:''',
'''Text''':
'''Szöveg''',
'''Titles''':
'''Címek''',
'''Search''':
'''Keresés''',
'''More Actions:''':
'''További műveletek:''',
'''Raw Text''':
'''Nyers szöveg megjelenítése''',
'''Delete Cache''':
'''Gyorstár törlése''',
'''Delete Page''':
'''Lap törlése''',
'''Like Pages''':
'''Hasonló lapok''',
'''Local Site Map''':
'''Helyi laptérkép''',
'''My Pages''':
'''Saját (személyes) lapok''',
'''Subscribe User''':
'''Előfizetés (csoportos)''',
'''Package Pages''':
'''Oldalak csomagolása''',
'''Render as Docbook''':
'''Docbook nézet (XML)''',
'''Do''':
'''Végrehajtás''',
'''Edit (Text)''':
'''Szerkesztés (szöveges módban)''',
'''Edit (GUI)''':
'''Szerkesztés (grafikus szerkesztővel)''',
'''Immutable Page''':
'''Nem szerkeszthető lap''',
'''Remove Link''':
'''Gyorslink törlése''',
'''Add Link''':
'''Gyorslink készítése''',
'''Attachments''':
'''Mellékletek (fájlok)''',
'''Show %s days.''':
'''%s nap megjelenítése''',
'''DeleteCache''':
'''GyorstárTörlés''',
'''(cached %s)''':
'''(a gyorstárba került: %s)''',
'''Or try one of these actions:''':
'''Esetleg próbáljon ki egyet ezekből a műveletekből:''',
'''Page''':
'''Oldal''',
'''User''':
'''Felhasználó''',
'''Sorry, can not save page because "%(content)s" is not allowed in this wiki.''':
'''A lapot nem lehet elmenteni, mert a(z) "%(content)s" nem engedélyezett ebben a wikiben.''',
'''Line''':
'''Sor''',
'''Deletions are marked like this.''':
'''A törléseket így jelöljük.''',
'''Additions are marked like this.''':
'''A kiegészítéseket így jelöljük.''',
'''Connection to mailserver \'%(server)s\' failed: %(reason)s''':
'''A(z) \'%(server)s\' levelező-kiszolgálóhoz nem sikerült kapcsolódni, ok: %(reason)s''',
'''Mail not sent''':
'''A levelet nem sikerült elküldeni.''',
'''Mail sent OK''':
'''A levelet sikerült elküldeni.''',
}
