"""
    This is a dummy file to feed some stuff into gettext system
    that it would not get otherwise - for automatic generation 
    of the translation files.

"""

def _(text): pass

_('FrontPage')
_('RecentChanges')
_('TitleIndex')
_('WordIndex')
_('FindPage')
_('SiteNavigation')
_('HelpContents')
_('HelpOnFormatting')
_('UserPreferences')
_('WikiLicense')
_('MissingPage')
_('MissingHomePage')

_('Mon'), _('Tue'), _('Wed'), _('Thu'), _('Fri'), _('Sat'), _('Sun')

_('AttachFile')
_('DeletePage')
_('LikePages')
_('LocalSiteMap')
_('RenamePage')
_('SpellCheck')

