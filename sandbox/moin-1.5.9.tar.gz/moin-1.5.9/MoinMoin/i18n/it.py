# -*- coding: utf-8 -*-
# Text translations for Italiano (it).
# Automatically generated - DO NOT EDIT, edit it.po instead!
meta = {
  'language': """Italiano""",
  'elanguage': """Italian""",
  'maintainer': """***vacant***""",
  'encoding': 'utf-8',
  'direction': 'ltr',
  'wikimarkup': True,
}
text = {
'''The backed up content of this page is deprecated and will not be included in search results!''':
'''La copia di backup di questa pagina è deprecata e pertanto non verrà inclusa nella ricerca!''',
'''Revision %(rev)d as of %(date)s''':
'''Versione %(rev)d del %(date)s''',
'''Redirected from page "%(page)s"''':
'''Redirezione dalla pagina "%(page)s"''',
'''This page redirects to page "%(page)s"''':
'''Questa pagina è rediretta alla pagina "%(page)s"''',
'''~-If you submit this form, the submitted values will be displayed.
To use this form on other pages, insert a
[[BR]][[BR]]\'\'\'{{{    [[Form("%(pagename)s")]]}}}\'\'\'[[BR]][[BR]]
macro call.-~
''':
'''~-Se confermi questa scheda, i dati inseriti verranno visulizzati.
Per usare questa maschera su altre pagine, inserisci una chiamata alla macro
[[BR]][[BR]]\'\'\'{{{    [[Form("%(pagename)s")]]}}}\'\'\'.[[BR]][[BR]]
~-
''',
'''Create New Page''':
'''Crea una nuova pagina''',
'''You are not allowed to view this page.''':
'''Non sei autorizzato a leggere questa pagina.''',
'''You are not allowed to edit this page.''':
'''Non ti è consentito di modificare questa pagina.''',
'''Page is immutable!''':
'''La pagina non è modificabile!''',
'''Cannot edit old revisions!''':
'''Non è permesso modificare le versioni precedenti!''',
'''The lock you held timed out. Be prepared for editing conflicts!''':
'''Il blocco alle modifiche che detenevi è scaduto, preparati a possibili conflitti di modifiche!''',
'''Edit "%(pagename)s"''':
'''Modifica "%(pagename)s"''',
'''Preview of "%(pagename)s"''':
'''Anteprima di "%(pagename)s"''',
'''Your edit lock on %(lock_page)s has expired!''':
'''Il tuo blocco alle modifiche su %(lock_page)s è scaduto!''',
'''Your edit lock on %(lock_page)s will expire in # minutes.''':
'''Il tuo blocco alle modifiche sulla pagina %(lock_page)s scadrà tra # minuti.''',
'''Your edit lock on %(lock_page)s will expire in # seconds.''':
'''Il tuo blocco alle modifiche sulla pagina %(lock_page)s scadrà tra # secondi.''',
'''Someone else deleted this page while you were editing!''':
'''Qualcun altro ha rimosso la pagina mentre la stavi modificando tu!''',
'''Someone else changed this page while you were editing!''':
'''Qualcun altro ha cambiato la pagina mentre la stavi modificando tu!''',
'''Someone else saved this page while you were editing!
Please review the page and save then. Do not save this page as it is!
Have a look at the diff of %(difflink)s to see what has been changed.''':
'''Qualcun altro ha salvato la pagina mentre la stavi modificando. Per favore, rivedi la pagina e salvala. Non salvarla così com\'è!
Dai un\'occhiata alle differenze in %(difflink)s per vedere cosa è cambiato.''',
'''[Content of new page loaded from %s]''':
'''[Contenuto della nuova pagina caricato da %s]''',
'''[Template %s not found]''':
'''[Il modello %s non è stato trovato]''',
'''[You may not read %s]''':
'''[Potresti non aver letto %s]''',
'''Describe %s here.''':
'''Inserisci una descrizione per %s''',
'''Check Spelling''':
'''Controllo ortografico''',
'''Save Changes''':
'''Salva le modifiche''',
'''Cancel''':
'''Annulla''',
'''By hitting \'\'\'%(save_button_text)s\'\'\' you put your changes under the %(license_link)s.
If you don\'t want that, hit \'\'\'%(cancel_button_text)s\'\'\' to cancel your changes.''':
'''Dando il comando \'\'\'%(save_button_text)s\'\'\' tu rilasci le tue modifiche sotto la %(license_link)s.
Se non vuoi questo, premi \'\'\'%(cancel_button_text)s\'\'\' per cancellare le tue modifiche.''',
'''Preview''':
'''Anteprima''',
'''Text mode''':
'''Modo testuale''',
'''Comment:''':
'''Commento:''',
'''<No addition>''':
'''<nessuna>''',
'''Add to: %(category)s''':
'''Aggiungi a: %(category)s''',
'''Trivial change''':
'''Cambiamento banale''',
'''Remove trailing whitespace from each line''':
'''Rimuovi gli spazi in fondo a ogni riga di testo''',
'''Invalid user name {{{\'%s\'}}}.
Name may contain any Unicode alpha numeric character, with optional one
space between words. Group page name is not allowed.''':
'''Nome utente {{{\'%s\'}}} non valido.
Il nome può contenere ogni carattere alfanumerico Unicode, con uno spazio opzionale tra le parole. Non è permesso utilizzare i nomi delle pagine di gruppo.''',
'''You are not allowed to do %s on this page.''':
'''Non ti è consentito di fare %s su questa pagina.''',
'''Login and try again.''':
'''Esegui login e prova ancora.''',
'''%(hits)d results out of about %(pages)d pages.''':
'''%(hits)d risultati su circa %(pages)d pagine consultate.''',
'''%.2f seconds''':
'''%.2f secondi''',
'''match''':
'''corrispondenza''',
'''matches''':
'''corrispondenze''',
'''<unknown>''':
'''<informazione non disponibile>''',
'''Login Name: %s

Login Password: %s

Login URL: %s/%s?action=login
''':
'''Nome login: %s

Password login: %s

URL login: %s/%s?action=login
''',
'''Somebody has requested to submit your account data to this email address.

If you lost your password, please use the data below and just enter the
password AS SHOWN into the wiki\'s password form field (use copy and paste
for that).

After successfully logging in, it is of course a good idea to set a new and known password.
''':
'''Qualcuno ha richiesto di mandare i dati relativi al tuo conto utente a questo
indirizzo email.

Se hai dimenticato la tua password, usa i dati riprodotti sotto e digita la
password ESATTAMENTE COME INDICATO nella corrispondente area del modulo nel
wiki (usa copia e incolla per questo).

Dopo aver eseguito il login, è un\'ottima idea impostare una nuova password.
''',
'''[%(sitename)s] Your wiki account data''':
'''[%(sitename)s] Dati del tuo conto utente wiki''',
'''This wiki is not enabled for mail processing.
Contact the owner of the wiki, who can enable email.''':
'''Questo wiki non è abilitato ad usare la mail. Contatta il gestore del wiki, o chi può abilitare la mail.''',
'''Please provide a valid email address!''':
'''Per favore immetti un indirizzo email valido!''',
'''Found no account matching the given email address \'%(email)s\'!''':
'''Non ho trovato nessun conto utente corrispondente all\'indirizzo email fornito \'%(email)s\'!''',
'''Use UserPreferences to change your settings or create an account.''':
'''Usa PreferenzeUtente per cambiare le tue impostazioni o per creare un nuovo conto utente.''',
'''Empty user name. Please enter a user name.''':
'''Nome utente vuoto. Inserisci un nome utente.''',
'''This user name already belongs to somebody else.''':
'''Questo nome utente è gia utilizzato da qualcun altro.''',
'''Passwords don\'t match!''':
'''Le password non coincidono!''',
'''Please specify a password!''':
'''Per favore specifica una password!''',
'''Please provide your email address. If you lose your login information, you can get it by email.''':
'''Per favore, inserisci il tuo indirizzo email: senza di esso non potrai riottenere i tuoi dati personali nel caso smarrissi la password.''',
'''This email already belongs to somebody else.''':
'''Questo indirizzo email è già utilizzato da qualcun altro.''',
'''User account created! You can use this account to login now...''':
'''Conto utente creato. Puoi usarlo per eseguire il login ora...''',
'''Use UserPreferences to change settings of the selected user account''':
'''Usa PreferenzeUtente per cambiare le impostazioni del profilo scelto.''',
'''The theme \'%(theme_name)s\' could not be loaded!''':
'''Il tema \'%(theme_name)s\' non può essere caricato.''',
'''User preferences saved!''':
'''Le preferenze utente sono state memorizzate!''',
'''Default''':
'''Prestabilito''',
'''<Browser setting>''':
'''<Impostazioni del browser>''',
'''the one preferred''':
'''quello preferito''',
'''free choice''':
'''a scelta''',
'''Select User''':
'''Seleziona utente''',
'''Save''':
'''Salva''',
'''Preferred theme''':
'''Tema preferito''',
'''Editor Preference''':
'''Editor preferito''',
'''Editor shown on UI''':
'''Editor mostrato''',
'''Time zone''':
'''Fuso orario''',
'''Your time is''':
'''La tua ora locale è''',
'''Server time is''':
'''L\'ora del server è''',
'''Date format''':
'''Formato data''',
'''Preferred language''':
'''Lingua preferita''',
'''General options''':
'''Opzioni generali''',
'''Quick links''':
'''Collegamenti rapidi''',
'''This list does not work, unless you have entered a valid email address!''':
'''Per un corretto funzionamento della notifica, devi inserire un indirizzo email valido!''',
'''Subscribed wiki pages (one regex per line)''':
'''Abbonato alle pagine (una espressione regolare per riga)''',
'''Create Profile''':
'''Crea il Profilo''',
'''Mail me my account data''':
'''Spediscimi via email i miei dati''',
'''Email''':
'''Email''',
'''To create an account or recover a lost password, see the %(userprefslink)s page.''':
'''Vedi la pagina %(userprefslink)s per creare un conto utente o per riottenere una password dimenticata.''',
'''Name''':
'''Nome''',
'''Password''':
'''Password''',
'''Login''':
'''Login''',
'''Action''':
'''Azione''',
'''Required attribute "%(attrname)s" missing''':
'''Manca l\'attributo obbligatorio "%(attrname)s" ''',
'''Submitted form data:''':
'''Dati inseriti:''',
'''Search Titles''':
'''Cerca per titolo''',
'''Display context of search results''':
'''Visualizza il contesto delle occorrenze trovate''',
'''Case-sensitive searching''':
'''Ricerca differenziando Maiuscolo-minuscolo''',
'''Search Text''':
'''Cerca nel testo''',
'''Go To Page''':
'''Vai alla pagina''',
'''Include system pages''':
'''Includi pagine di sistema''',
'''Exclude system pages''':
'''Escludi le pagine di sistema''',
'''Plain title index''':
'''Elenco testuale dei titoli''',
'''XML title index''':
'''Elenco dei titoli in XML''',
'''Python Version''':
'''Versione Python''',
'''MoinMoin Version''':
'''Versione MoinMoin''',
'''Release %s [Revision %s]''':
'''Versione %s [Revisione %s]''',
'''4Suite Version''':
'''Versione 4Suite''',
'''Number of pages''':
'''Numero di pagine''',
'''Number of system pages''':
'''Numero di pagine di sistema''',
'''Accumulated page sizes''':
'''Dimensione complessiva delle pagine''',
'''Disk usage of %(data_dir)s/pages/''':
'''Uso della memoria di %(data_dir)s/pages/''',
'''Disk usage of %(data_dir)s/''':
'''Uso della memoria disco di %(data_dir)s/''',
'''Entries in edit log''':
'''Voci nel registro delle modifiche''',
'''NONE''':
'''Nessuno''',
'''Global extension macros''':
'''Macro d\'estensione globali''',
'''Local extension macros''':
'''Macro d\'estensione locali''',
'''Global extension actions''':
'''Azioni d\'estensione globali''',
'''Local extension actions''':
'''Azioni d\'estensione locali''',
'''Global parsers''':
'''Parser d\'estensione globali''',
'''Local extension parsers''':
'''Parser d\'estensione locali''',
'''Installed processors (DEPRECATED -- use Parsers instead)''':
'''Processori installati (DEPRECATO -- usa i Parser)''',
'''Disabled''':
'''Disattivato''',
'''Enabled''':
'''Attivato''',
'''Lupy search''':
'''Ricerca Lupy''',
'''Active threads''':
'''Thread attivi''',
'''Please use a more selective search term instead of {{{"%s"}}}''':
'''Per favore usa un termine di ricerca più selettivo di {{{"%s"}}}''',
'''ERROR in regex \'%s\'''':
'''Errore nell\'espressione regolare \'%s\'''',
'''Bad timestamp \'%s\'''':
'''Specifica oraria non valida \'%s\'''',
'''Expected "=" to follow "%(token)s"''':
'''Manca un "=" dopo il testo "%(token)s"''',
'''Expected a value for key "%(token)s"''':
'''Manca il valore per la chiave "%(token)s"''',
'''Wiki Markup''':
'''Formattazione Wiki''',
'''Print View''':
'''Versione stampabile''',
'''Your changes are not saved!''':
'''Le tue modifiche non sono state salvate.''',
'''Page name is too long, try shorter name.''':
'''Il nome della pagina è troppo lungo, provane uno più corto''',
'''GUI Mode''':
'''Modo grafico''',
'''Edit was cancelled.''':
'''Le modifiche sono state annullate.''',
'''You can\'t rename to an empty pagename.''':
'''Non puoi rinominare la pagina in una senza nome.''',
'''\'\'\'A page with the name {{{\'%s\'}}} already exists.\'\'\'

Try a different name.''':
'''\'\'\'Una pagina con il nome {{{\'%s\'}}} esiste già.\'\'\'

Prova un nome differente.''',
'''Could not rename page because of file system error: %s.''':
'''Impossibile rinominare la pagina per un errore del file system: %s.''',
'''Thank you for your changes. Your attention to detail is appreciated.''':
'''Grazie per il tuo contributo. La tua attenzione ai dettagli è apprezzata.''',
'''Page "%s" was successfully deleted!''':
'''La pagina "%s" è stata cancellata correttamente!''',
'''Dear Wiki user,

You have subscribed to a wiki page or wiki category on "%(sitename)s" for change notification.

The following page has been changed by %(editor)s:
%(pagelink)s

''':
'''Caro utente Wiki,
ti sei abbonato alla notifica in caso di modifiche a una pagina o a una
categoria sul sito Wiki "%(sitename)s".
Le pagine seguenti sono state modificate da %(editor)s:
%(pagelink)s
''',
'''The comment on the change is:
%(comment)s

''':
'''Il commento alle modifiche:
%(comment)s
''',
'''New page:
''':
'''Nuova pagina:
''',
'''No differences found!
''':
'''Non ho riscontrato nessuna differenza!
''',
'''[%(sitename)s] %(trivial)sUpdate of "%(pagename)s" by %(username)s''':
'''[%(sitename)s] %(trivial)sCambiamenti della "%(pagename)s" ad opera di %(username)s''',
'''Trivial ''':
'''Banale ''',
'''Status of sending notification mails:''':
'''Risultato della spedizione delle email di notifica:''',
'''[%(lang)s] %(recipients)s: %(status)s''':
'''[%(lang)s] %(recipients)s: %(status)s''',
'''## backup of page "%(pagename)s" submitted %(date)s''':
'''## copia di salvataggio della pagina "%(pagename)s" inviata %(date)s''',
'''Page could not get locked. Unexpected error (errno=%d).''':
'''Impossibile bloccare la pagina. Errore inaspettato (errno=%d).''',
'''Page could not get locked. Missing \'current\' file?''':
'''Impossibile bloccare la pagina. Manca il file \'current\'?''',
'''You are not allowed to edit this page!''':
'''Non sei autorizzato a modificare questa pagina!''',
'''You cannot save empty pages.''':
'''Non puoi salvare pagine vuote.''',
'''You already saved this page!''':
'''Hai già salvato questa pagina.''',
'''Sorry, someone else saved the page while you edited it.

Please do the following: Use the back button of your browser, and cut&paste
your changes from there. Then go forward to here, and click EditText again.
Now re-add your changes to the current page contents.

\'\'Do not just replace
the content editbox with your version of the page, because that would
delete the changes of the other person, which is excessively rude!\'\'
''':
'''Mi dispiace, ma qualcun altro ha salvato la pagina mentre la stavi modificando.

Dovresti tornare alla pagina precedende e copiarti il
testo che hai inserito, dopodiché tornare qui, premere ModificaIlTesto di nuovo.
A quel punto re-integra le tue modifiche nella pagina corrente.

\'\'Non limitarti a sostituire il contenuto della pagina con le tue
modifiche, perché in tal modo cancelleresti le modifiche dell\'altra
persona, il che sarebbe eccessivamente sgarbato!\'\'
''',
'''A backup of your changes is [%(backup_url)s here].''':
'''Una copia salvata delle tue modifiche è disponibile [%(backup_url)s qui].''',
'''You did not change the page content, not saved!''':
'''Non hai modificato il contenuto della pagina che per questo non è stata salvata.''',
'''You can\'t change ACLs on this page since you have no admin rights on it!''':
'''Non puoi modificare i diritti di accesso (ACL) di questa pagina dal momento che non hai i permessi di amministrazione su di essa!''',
'''The lock of %(owner)s timed out %(mins_ago)d minute(s) ago, and you were granted the lock for this page.''':
'''Il blocco alle modifiche di %(owner)s è scaduto %(mins_ago)d minuto/i fa, e ti è stato concesso il blocco di questa pagina.''',
'''Other users will be \'\'blocked\'\' from editing this page until %(bumptime)s.''':
'''Gli altri utenti saranno \'\'bloccati\'\' nelle modifiche a questa pagina fino a  %(bumptime)s.''',
'''Other users will be \'\'warned\'\' until %(bumptime)s that you are editing this page.''':
'''Gli altri utenti saranno \'\'avvisati\'\' fino a %(bumptime)s che stai modificando la pagina.''',
'''Use the Preview button to extend the locking period.''':
'''Usa il pulsante Anteprima per estendere il periodo di blocco.''',
'''This page is currently \'\'locked\'\' for editing by %(owner)s until %(timestamp)s, i.e. for %(mins_valid)d minute(s).''':
'''Questa pagina rimarrà \'\'bloccata\'\' fino alle %(timestamp)s, vale a dire ancora per %(mins_valid)d minuti, perché %(owner)s la sta modificando.''',
'''This page was opened for editing or last previewed at %(timestamp)s by %(owner)s.[[BR]]
\'\'\'You should \'\'refrain from editing\'\' this page for at least another %(mins_valid)d minute(s),
to avoid editing conflicts.\'\'\'[[BR]]
To leave the editor, press the Cancel button.''':
'''Questa pagina risulta in modifica dalle %(timestamp)s da parte di %(owner)s o perlomeno ne ha richiesto un\'anteprima a quell\'ora.[[BR]]
\'\'\'Dovresti \'\'evitare di modificare\'\' questa pagina per almeno altri %(mins_valid)d minuti per non incorrere in probabili conflitti.\'\'\'[[BR]]
Premi il pulsante Annulla per lasciare l\'editor.''',
'''The package needs a newer version of MoinMoin (at least %s).''':
'''Questo pacchetto richiede una versione di MoinMoin più attuale (%s o più).''',
'''The theme name is not set.''':
'''Il nome del tema non è stato specificato.''',
'''Installing theme files is only supported for standalone type servers.''':
'''L\'installazione di file di tema è possibile solo su server indipendenti.''',
'''Installation of \'%(filename)s\' failed.''':
'''L\'installazione di \'%(filename)s\' è fallita.''',
'''The file %s is not a MoinMoin package file.''':
'''Il file %s non è un pacchetto di MoinMoin.''',
'''The page %s does not exist.''':
'''La pagina %s risulta inesistente.''',
'''Invalid package file header.''':
'''Intestazione del pacchetto invalida.''',
'''Package file format unsupported.''':
'''Formato del file del pacchetto non supportato.''',
'''Unknown function %(func)s in line %(lineno)i.''':
'''Funzione sconosciuta %(func)s alla riga %(lineno)i.''',
'''The file %s was not found in the package.''':
'''Impossibile trovare il file %s nel pacchetto.''',
''' Emphasis:: [[Verbatim(\'\')]]\'\'italics\'\'[[Verbatim(\'\')]]; [[Verbatim(\'\'\')]]\'\'\'bold\'\'\'[[Verbatim(\'\'\')]]; [[Verbatim(\'\'\'\'\')]]\'\'\'\'\'bold italics\'\'\'\'\'[[Verbatim(\'\'\'\'\')]]; [[Verbatim(\'\')]]\'\'mixed \'\'[[Verbatim(\'\'\')]]\'\'\'\'\'bold\'\'\'[[Verbatim(\'\'\')]] and italics\'\'[[Verbatim(\'\')]]; [[Verbatim(----)]] horizontal rule.
 Headings:: [[Verbatim(=)]] Title 1 [[Verbatim(=)]]; [[Verbatim(==)]] Title 2 [[Verbatim(==)]]; [[Verbatim(===)]] Title 3 [[Verbatim(===)]];   [[Verbatim(====)]] Title 4 [[Verbatim(====)]]; [[Verbatim(=====)]] Title 5 [[Verbatim(=====)]].
 Lists:: space and one of: * bullets; 1., a., A., i., I. numbered items; 1.#n start numbering at n; space alone indents.
 Links:: [[Verbatim(JoinCapitalizedWords)]]; [[Verbatim(["brackets and double quotes"])]]; url; [url]; [url label].
 Tables:: || cell text |||| cell text spanning 2 columns ||;    no trailing white space allowed after tables or titles.

(!) For more help, see HelpOnEditing or SyntaxReference.
''':
''' Enfasi:: [[Verbatim(\'\')]]\'\'corsivo\'\'[[Verbatim(\'\')]]; [[Verbatim(\'\'\')]]\'\'\'grassetto\'\'\'[[Verbatim(\'\'\')]]; [[Verbatim(\'\'\'\'\')]]\'\'\'\'\'grassetto corsivo\'\'\'\'\'[[Verbatim(\'\'\'\'\')]]; [[Verbatim(\'\')]]\'\'misto \'\'[[Verbatim(\'\'\')]]\'\'\'\'\'grassetto\'\'\'[[Verbatim(\'\'\')]] e corsivo\'\'[[Verbatim(\'\')]]; [[Verbatim(----)]] linea orizzontale.
 Intestazioni:: [[Verbatim(=)]] Titolo 1 [[Verbatim(=)]]; [[Verbatim(==)]] Titolo 2 [[Verbatim(==)]]; [[Verbatim(===)]] Titolo 3 [[Verbatim(===)]];   [[Verbatim(====)]] Titolo 4 [[Verbatim(====)]]; [[Verbatim(=====)]] Titolo 5 [[Verbatim(=====)]].
 Liste:: spazio e uno di: * elenco puntato; 1., a., A., i., I. per elenco numerato; 1.#n inizia la numerazione da n; lo spazio da solo indenta.
 Collegamenti:: [[Verbatim(ParoleConLettereMaiuscole)]]; [[Verbatim(["parentesi quadre e doppie virgolette"])]]; url; [url]; [url label].
 Tabelle:: || cela di testo |||| cella su due colonne ||;    non sono consentiti spazi dopo la tabella o il titolo.

(!) Per ulteriore aiuto, vedi AiutoSuModificaPagina o RiassuntoDellaSintassi.
''',
'''Emphasis: <i>*italic*</i> <b>**bold**</b> ``monospace``<br/>
<br/><pre>
Headings: Heading 1  Heading 2  Heading 3
          =========  ---------  ~~~~~~~~~

Horizontal rule: ---- 
Links: TrailingUnderscore_ `multi word with backticks`_ external_ 

.. _external: http://external-site.net/foo/

Lists: * bullets; 1., a. numbered items.
</pre>
<br/>
(!) For more help, see the 
<a href="http://docutils.sourceforge.net/docs/user/rst/quickref.html">
reStructuredText Quick Reference
</a>.
''':
'''Enfasi: <i>*corsivo*</i> <b>**grassetto**</b> ``a spaziatura fissa``<br/>
<br/><pre>
Titoli: Titolo 1  Titolo 2  Titolo 3
        ========  --------  ~~~~~~~~

Linea orizzontale: ---- 
Collegamenti: SottolineAttaccata_ `più parole con accenti`_ esterno_ 

.. _esterno: http://example.net/foo/

Liste: * punti; 1., a. numeri.
</pre>
<br/>
(!) Per informazioni ulteriori si prega di consultare il 
<a href="http://docutils.sourceforge.net/docs/user/rst/quickref.html">
reStructuredText Quick Reference
</a>.
''',
'''Diffs''':
'''differenze''',
'''Info''':
'''Informazioni''',
'''Edit''':
'''Modifica''',
'''UnSubscribe''':
'''Annulla sottoscrizione''',
'''Subscribe''':
'''Sottoscrivi''',
'''Raw''':
'''Non formattato''',
'''XML''':
'''XML''',
'''Print''':
'''Versione stampabile''',
'''View''':
'''mostra''',
'''Up''':
'''Sù''',
'''Publish my email (not my wiki homepage) in author info''':
'''Pubblicare la mia email anzichè la pagina personale come informazione sull\'autore''',
'''Open editor on double click''':
'''Con un doppio click, apri l\'editor''',
'''Jump to last visited page instead of frontpage''':
'''Vai all\'ultima pagina visitata anzichè alla pagina iniziale''',
'''Show question mark for non-existing pagelinks''':
'''Mostra un punto di domanda per i collegamenti a pagine non esistenti''',
'''Show page trail''':
'''Mostra il piè di pagina''',
'''Show icon toolbar''':
'''Mostra la barra con le icone''',
'''Show top/bottom links in headings''':
'''Mostra i link inizio/fine nelle intestazioni''',
'''Show fancy diffs''':
'''Evidenzia le differenze''',
'''Add spaces to displayed wiki names''':
'''Aggiungi uno spazio tra le singole parole dei nomi wiki''',
'''Remember login information''':
'''Ricorda le mie informazioni di login''',
'''Subscribe to trivial changes''':
'''Sottoscrivi per i cambiamenti banali''',
'''Disable this account forever''':
'''Disabilita questo conto utente per sempre''',
'''(Use Firstname\'\'\'\'\'\'Lastname)''':
'''(Usa la forma Nome\'\'\'\'\'\'Cognome)''',
'''Alias-Name''':
'''Nome alias''',
'''Password repeat''':
'''Ripeti la password''',
'''(Only when changing passwords)''':
'''(Solo quando si modifica la password)''',
'''User CSS URL''':
'''URL del CSS''',
'''(Leave it empty for disabling user CSS)''':
'''(Lascia vuoto per disabilitare il CSS)''',
'''Editor size''':
'''Dimensione dell\'editor''',
'''No older revisions available!''':
'''Non ci sono revisioni precedenti!''',
'''Diff for "%s"''':
'''Differenze per "%s"''',
'''Differences between revisions %d and %d''':
'''Differenze tra le versioni del %d e del %d''',
'''(spanning %d versions)''':
'''(in %d Versioni)''',
'''No differences found!''':
'''Non ho riscontrato nessuna differenza!''',
'''The page was saved %(count)d times, though!''':
'''La pagina è stata comunque salvata %(count)d volte!''',
'''(ignoring whitespace)''':
'''(ignorando gli spazi vuoti)''',
'''Ignore changes in the amount of whitespace''':
'''Ignora differenze nella spaziatura''',
'''General Information''':
'''Informazioni generali''',
'''Page size: %d''':
'''Dimensione pagina: %d''',
'''SHA digest of this page\'s content is:''':
'''Totale di controllo (metodo SHA) del contenuto di questa pagina:''',
'''The following users subscribed to this page:''':
'''Elenco degli abbonati a questa pagina:''',
'''This page links to the following pages:''':
'''Questa pagina contiene collegamenti alle seguenti pagine:''',
'''Date''':
'''Data''',
'''Size''':
'''Dimensione''',
'''Diff''':
'''Differenze''',
'''Editor''':
'''Autore''',
'''Comment''':
'''Commento''',
'''view''':
'''mostra''',
'''raw''':
'''non formattato''',
'''print''':
'''stampa''',
'''revert''':
'''ripristina''',
'''Revert to revision %(rev)d.''':
'''Ripristinata la revisione %(rev)d.''',
'''edit''':
'''modifica''',
'''get''':
'''scarica''',
'''del''':
'''rimuovi''',
'''N/A''':
'''N/D''',
'''Revision History''':
'''Cronologia revisioni''',
'''No log entries found.''':
'''Non sono stati trovate informazioni nel log.''',
'''Info for "%s"''':
'''Informazioni su "%s"''',
'''Show "%(title)s"''':
'''Mostra "%(title)s"''',
'''General Page Infos''':
'''Informazioni generali''',
'''Show chart "%(title)s"''':
'''Mostra il grafico "%(title)s"''',
'''Page hits and edits''':
'''Richieste e modifiche alla pagina''',
'''You are not allowed to revert this page!''':
'''Non sei autorizzato a ripristinare questa pagina!''',
'''You must login to add a quicklink.''':
'''Bisogna esequire il login per aggiungere un collegamento rapido.''',
'''Your quicklink to this page has been removed.''':
'''Il tuo collegamento rapido è stato rimosso.''',
'''A quicklink to this page has been added for you.''':
'''Un collegamento rapido a questa pagina è stato creato.''',
'''You are not allowed to subscribe to a page you can\'t read.''':
'''Non ti è consentito abbonarti a pagine che non puoi leggere.''',
'''This wiki is not enabled for mail processing.''':
'''Questo wiki non è abilitato ad usare la mail. Contatta il gestore del wiki, o chi può abilitare la mail.''',
'''You must log in to use subscribtions.''':
'''Bisogna esequire il login per potersi abbonare.''',
'''Add your email address in your UserPreferences to use subscriptions.''':
'''Bisogna fornire un indirizzo email nelle PreferenzeUtente per potersi abbonare alle pagine.''',
'''Your subscribtion to this page has been removed.''':
'''Il tuo abbonamento a questa pagina è stato rimosso.''',
'''Can\'t remove regular expression subscription!''':
'''Non posso rimuovere la sottoscrizione con espressione regolare''',
'''Edit the subscription regular expressions in your UserPreferences.''':
'''Modificare le espressioni regolari per abbonamenti su PreferenzeUtente.''',
'''You have been subscribed to this page.''':
'''Da questo momento sei abbonato a questa pagina.''',
'''Charts are not available!''':
'''Grafici non disponibili!''',
'''You need to provide a chart type!''':
'''Devi specificare un tipo di grafico!''',
'''Bad chart type "%s"!''':
'''Tipo di grafico "%s" non valido!''',
'''This page is already deleted or was never created!''':
'''Questa pagina è gia stata cancellata, o non è mai stata creata!''',
'''No pages like "%s"!''':
'''Nessuna pagina simile a "%s"!''',
'''Invalid filename "%s"!''':
'''Nome di file "%s" invalido.''',
'''Attachment \'%(target)s\' (remote name \'%(filename)s\') already exists.''':
'''L\'allegato \'%(target)s\' (nome originale \'%(filename)s\') già esiste.''',
'''Created the package %s containing the pages %s.''':
'''Il pacchetto %s contenente le pagini %s è stato creato.''',
'''Package pages''':
'''Pagine del pacchetto''',
'''Package name''':
'''Nome del pacchetto''',
'''List of page names - separated by a comma''':
'''Elenco dei nomi di pagina, separati da virgole''',
'''Unknown user name: {{{"%s"}}}. Please enter user name and password.''':
'''Nome utente sconosciuto: {{{"%s"}}}. Inserisci nome utente e password.''',
'''Missing password. Please enter user name and password.''':
'''Password mancante. Inserisci nome utente e password.''',
'''Sorry, wrong password.''':
'''Spiacente, password errata.''',
'''Exactly one page like "%s" found, redirecting to page.''':
'''Trovata esattamente una pagina per "%s", redirect alla pagina.''',
'''Pages like "%s"''':
'''Pagine come "%s"''',
'''%(matchcount)d %(matches)s for "%(title)s"''':
'''%(matchcount)d %(matches)s per "%(title)s"''',
'''Local Site Map for "%s"''':
'''Mappa del sito per "%s"''',
'''Please log in first.''':
'''Bisogna di prima eseguire il login.''',
'''Please first create a homepage before creating additional pages.''':
'''Creare una pagina personale prima di creare pagine supplementari, per favore.''',
'''You can add some additional sub pages to your already existing homepage here.

You can choose how open to other readers or writers those pages shall be,
access is controlled by group membership of the corresponding group page.

Just enter the sub page\'s name and click on the button to create a new page.

Before creating access protected pages, make sure the corresponding group page
exists and has the appropriate members in it. Use HomepageGroupsTemplate for creating
the group pages.

||\'\'\'Add a new personal page:\'\'\'||\'\'\'Related access control list group:\'\'\'||
||[[NewPage(HomepageReadWritePageTemplate,read-write page,%(username)s)]]||["%(username)s/ReadWriteGroup"]||
||[[NewPage(HomepageReadPageTemplate,read-only page,%(username)s)]]||["%(username)s/ReadGroup"]||
||[[NewPage(HomepagePrivatePageTemplate,private page,%(username)s)]]||%(username)s only||

''':
'''Qui puoi aggiungere qualche sottopagina supplementare alla tua pagina personale già esistente.

Puoi scegliere per quanto essa sia aperta agli altri lettori e/o autori;
l\'accesso è controllato per via della appartenenza in un gruppo sulla
corrispondente pagina di gruppo.

Digita il nome della sottopagina e clicca sul bottone per crearla.

Prima di creare una pagina ad accesso limitato, assicurati che una corrispondente pagina
di gruppo esista e che ci siano elencati gli utenti desiderati.
Usa l\' HomepageGroupsTemplate per creare le pagine di gruppo.

||\'\'\'Aggiungi una nuova pagina personale:\'\'\'||\'\'\'Relativa lista di controllo dell\'accesso (ACL):\'\'\'||
||[[NewPage(HomepageReadWritePageTemplate,read-write page,%(username)s)]]||["%(username)s/ReadWriteGroup"]||
||[[NewPage(HomepageReadPageTemplate,read-only page,%(username)s)]]||["%(username)s/ReadGroup"]||
||[[NewPage(HomepagePrivatePageTemplate,private page,%(username)s)]]||%(username)s only||

''',
'''MyPages management''':
'''Amministrazione di MyPages''',
'''Rename Page''':
'''Rinomina Pagina''',
'''New name''':
'''Nuovo nome''',
'''Optional reason for the renaming''':
'''Ragione facoltativa per la rinominazione''',
'''(including %(localwords)d %(pagelink)s)''':
'''(includendo %(localwords)d %(pagelink)s)''',
'''The following %(badwords)d words could not be found in the dictionary of %(totalwords)d words%(localwords)s and are highlighted below:''':
'''Le seguenti %(badwords)d parole non sono state trovate nel dizionario di %(totalwords)d termini%(localwords)s e sono evidenziate qui sotto:''',
'''Add checked words to dictionary''':
'''Aggiungi le parole verificate al dizionario''',
'''No spelling errors found!''':
'''Non sono stati trovati errori di ortografia!''',
'''You can\'t check spelling on a page you can\'t read.''':
'''Non puoi effettuare il controllo ortografica sulle pagine che non puoi leggere.''',
'''Do it.''':
'''Esegui!''',
'''Execute action %(actionname)s?''':
'''Eseguire azione %(actionname)s?''',
'''Action %(actionname)s is excluded in this wiki!''':
'''L\'azione %(actionname)s è disponibile in questo wiki.''',
'''You are not allowed to use action %(actionname)s on this page!''':
'''Non ti è consentito di usare l\'azione %(actionname)s con questa pagina.''',
'''Please use the interactive user interface to use action %(actionname)s!''':
'''Usare l\'interfaccia interattiva per usare l\'azione %(actionname)s, per favore.''',
'''Title Search: "%s"''':
'''Ricerca "%s" nei titoli''',
'''Full Text Search: "%s"''':
'''Ricerca nel contenuto per "%s"''',
'''Full Link List for "%s"''':
'''Elenco completo dei collegamenti per "%s"''',
'''Cannot create a new page without a page name.  Please specify a page name.''':
'''Impossibile creare una nuova pagina senza nome.  Inserire il nome della pagina''',
'''Pages''':
'''Pagine''',
'''Select Author''':
'''Selezionare autore''',
'''Revert all!''':
'''Ripristinare tutti''',
'''You are not allowed to use this action.''':
'''Non ti è consentito di usare questa azione.''',
'''Subscribe users to the page %s''':
'''Abbonati alla pagina %s''',
'''Subscribed for %s:''':
'''Abbonati per %s:''',
'''Not a user:''':
'''Non è un utente:''',
'''You are not allowed to perform this action.''':
'''Non ti è consentito di eseguire questa azione.''',
'''You are now logged out.''':
'''Sei stato disconnesso.''',
'''Delete''':
'''Cancella''',
'''Optional reason for the deletion''':
'''Ragione facoltativa per la cancellazione''',
'''Really delete this page?''':
'''Vuoi veramente cancellare questa pagina?''',
'''Restored Backup: %(filename)s to target dir: %(targetdir)s.
Files: %(filecount)d, Directories: %(dircount)d''':
'''Backup %(filename)s ripristinato nella cartella di destinazione %(targetdir)s.
N. file: %(filecount)d, n. cartelle: %(dircount)d''',
'''Restoring backup: %(filename)s to target dir: %(targetdir)s failed.''':
'''Recupero della copia di salvataggio %(filename)s nella cartella di
destinazione %(targetdir)s fallito.''',
'''Wiki Backup / Restore''':
'''Wiki Backup / Recupero''',
'''Some hints:
 * To restore a backup:
  * Restoring a backup will overwrite existing data, so be careful.
  * Rename it to <siteid>.tar.<compression> (remove the --date--time--UTC stuff).
  * Put the backup file into the backup_storage_dir (use scp, ftp, ...).
  * Hit the [[GetText(Restore)]] button below.

 * To make a backup, just hit the [[GetText(Backup)]] button and save the file
   you get to a secure place.

Please make sure your wiki configuration backup_* values are correct and complete.

''':
'''Alcuni suggerimenti:
 * Per ripristinare una backup:
  * Attenzione, ripristinare una backup sovrascriverà i dati esistenti.
  * Renomina la backup in <siteid>.tar.<compression> (rimuovi tutto il --date--time--UTC)
  * Metti il file di backup nella cartella_di_archiviazione_delle_backup (usa scp, ftp, ...).
  * Clicca sul bottone [[GetText(Restore)]] qui sotto.

 * Per fare una copia di salvataggio (backup), clicca sul bottone [[GetText(Backup)]] e salva il file
   che otterrai in un posto sicuro.

Assicurati che la configurazione dei parametri backup_* nel tuo wiki siano corretti e completi.

''',
'''Backup''':
'''Backup''',
'''Restore''':
'''Ripristina''',
'''You are not allowed to do remote backup.''':
'''Non ti è consentito di esequire un backup a distanza.''',
'''Unknown backup subaction: %s.''':
'''Sottoazione di backup %s sconosciuta.''',
'''[%d attachments]''':
'''[%d allegati]''',
'''There are <a href="%(link)s">%(count)s attachment(s)</a> stored for this page.''':
'''Ci sono <a href="%(link)s">%(count)s allegati</a> per questa pagina.''',
'''Filename of attachment not specified!''':
'''Non è stato specificato il nome del file dell\'allegato!''',
'''Attachment \'%(filename)s\' does not exist!''':
'''L\'allegato \'%(filename)s\' non esiste!''',
'''To refer to attachments on a page, use \'\'\'{{{attachment:filename}}}\'\'\', 
as shown below in the list of files. 
Do \'\'\'NOT\'\'\' use the URL of the {{{[get]}}} link, 
since this is subject to change and can break easily.''':
'''Per riferirti agli allegati di una pagina, usa \'\'\'{{{attachment:filename}}}\'\'\',
come mostrato qui sotto nella lista degli allegati.
\'\'\'NON\'\'\' usare l\'URL che trovi in corrispondenza del link {{{[get]}}},
dal momento che potrebbe cambiare in futuro.''',
'''unzip''':
'''decomprimi''',
'''install''':
'''installa''',
'''No attachments stored for %(pagename)s''':
'''Non ci sono allegati nella pagina %(pagename)s''',
'''Edit drawing''':
'''Modifica il disegno''',
'''Attached Files''':
'''File allegati''',
'''You are not allowed to attach a file to this page.''':
'''Non sei autorizzato a inserire allegati in questa pagina!''',
'''New Attachment''':
'''Nuovo allegato''',
'''An upload will never overwrite an existing file. If there is a name
conflict, you have to rename the file that you want to upload.
Otherwise, if "Rename to" is left blank, the original filename will be used.''':
'''Non sarà permessa la sovrascrittura di un file esistente. In
caso di conflitto, dovrai cambiare il nome del file che vuoi caricare.
Altrimenti, se "Rinomina come" viene lasciato in bianco, verrà
usato il nome originale del file.''',
'''File to upload''':
'''File da caricare''',
'''Rename to''':
'''Cambia nome a''',
'''Upload''':
'''Carica''',
'''File attachments are not allowed in this wiki!''':
'''File allegati non consentiti in questo wiki!''',
'''You are not allowed to save a drawing on this page.''':
'''Non sei autorizzato a salvare un disegno in questa pagina!''',
'''No file content. Delete non ASCII characters from the file name and try again.''':
'''Nessun contenuto. Cancella i caratteri non ASCII dal nome file e prova ancora.''',
'''You are not allowed to delete attachments on this page.''':
'''Non sei autorizzato a cancellare i file allegati.''',
'''You are not allowed to get attachments from this page.''':
'''Non sei autorizzato ad accedere agli allegati.''',
'''You are not allowed to unzip attachments of this page.''':
'''Non ti è consentito di decomprimere gli allegati di questa pagina.''',
'''You are not allowed to install files.''':
'''Non ti è consentito di installare dei file.''',
'''You are not allowed to view attachments of this page.''':
'''Non sei autorizzato a vedere gli allegati.''',
'''Unsupported upload action: %s''':
'''Azione di caricamento non supportata: %s''',
'''Attachments for "%(pagename)s"''':
'''Allegati per "%(pagename)s"''',
'''Attachment \'%(target)s\' (remote name \'%(filename)s\') with %(bytes)d bytes saved.''':
'''L\'allegato \'%(target)s\' (nome originale \'%(filename)s\') di %(bytes)d byte è stato memorizzato.''',
'''Attachment \'%(filename)s\' deleted.''':
'''L\'allegato \'%(filename)s\' è stato cancellato.''',
'''Attachment \'%(filename)s\' installed.''':
'''L\'allegato \'%(filename)s\' è stato installato.''',
'''Attachment \'%(filename)s\' could not be unzipped because the resulting files would be too large (%(space)d kB missing).''':
'''Impossibile di decomprimere l\'allegato \'%(filename)s\' perché eccederebbe la memoria disponibile (%(space)d kB mancanti).''',
'''Attachment \'%(filename)s\' could not be unzipped because the resulting files would be too many (%(count)d missing).''':
'''Impossibile di decomprimere l\'allegato \'%(filename)s\' perché eccederebbe il numero possibile di file (%(count)d mancanti).''',
'''Attachment \'%(filename)s\' unzipped.''':
'''L\'allegato \'%(filename)s\' è stato decompresso.''',
'''Attachment \'%(filename)s\' not unzipped because the files are too big, .zip files only, exist already or reside in folders.''':
'''Impossibile decomprimere l\'allegato \'%(filename)s\' perché troppo grande o non di tipo .zip o esiste già o ubicato in una cartella.''',
'''The file %(target)s is not a .zip file.''':
'''Il file %(target)s non è di tipo .zip.''',
'''Attachment \'%(filename)s\'''':
'''L\'allegato \'%(filename)s\'''',
'''Package script:''':
'''Script del pacchetto:''',
'''File Name''':
'''Nome del file''',
'''Modified''':
'''Modificato''',
'''Unknown file type, cannot display this attachment inline.''':
'''Tipo di file sconosciuto, non posso visualizzarlo direttamente nella pagina.''',
'''attachment:%(filename)s of %(pagename)s''':
'''[[Verbatim(attachment:)]]%(filename)s di %(pagename)s''',
'''Upload new attachment "%(filename)s"''':
'''Carica nuovo allegato "%(filename)s"''',
'''Create new drawing "%(filename)s"''':
'''Crea un nuovo disegno "%(filename)s"''',
'''Edit drawing %(filename)s''':
'''Modifica disegno "%(filename)s"''',
'''Toggle line numbers''':
'''Dis/Attivare numerazione di righe''',
'''FrontPage''':
'''PaginaPrincipale''',
'''RecentChanges''':
'''ModificheRecenti''',
'''TitleIndex''':
'''IndiceDeiTitoli''',
'''WordIndex''':
'''IndicePerParola''',
'''FindPage''':
'''CercaPagina''',
'''SiteNavigation''':
'''NavigaIlSito''',
'''HelpContents''':
'''AiutoContenuti''',
'''HelpOnFormatting''':
'''AiutoSuFormattazione''',
'''UserPreferences''':
'''PreferenzeUtente''',
'''WikiLicense''':
'''LicenzaWiki''',
'''MissingPage''':
'''PaginaMancante''',
'''MissingHomePage''':
'''PaginaPersonaleMancante''',
'''Mon''':
'''lun''',
'''Tue''':
'''mar''',
'''Wed''':
'''mer''',
'''Thu''':
'''gio''',
'''Fri''':
'''ven''',
'''Sat''':
'''sab''',
'''Sun''':
'''dom''',
'''AttachFile''':
'''File allegati''',
'''DeletePage''':
'''CancellaPagina''',
'''LikePages''':
'''PagineSimili''',
'''LocalSiteMap''':
'''MappaLocaleSito''',
'''RenamePage''':
'''RinominaPagina''',
'''SpellCheck''':
'''ControlloOrtografico''',
'''Invalid MonthCalendar calparms "%s"!''':
'''Parametri "%s" per il calendario invalidi.''',
'''Invalid MonthCalendar arguments "%s"!''':
'''Argomenti "%s" per il calendario invalidi.''',
'''Unsupported navigation scheme \'%(scheme)s\'!''':
'''Schema di navigazione \'%(scheme)s\' non supportato!''',
'''No parent page found!''':
'''La pagina sovrastante non è stata trovata!''',
'''Wiki''':
'''Wiki''',
'''Slideshow''':
'''Diapositive''',
'''Start''':
'''Inizia''',
'''Slide %(pos)d of %(size)d''':
'''Diapositiva %(pos)d di %(size)d ''',
'''No orphaned pages in this wiki.''':
'''Non ci sono pagine orfane (non referenziate da qualche altra pagina) in questo wiki.''',
'''No quotes on %(pagename)s.''':
'''La pagina %(pagename)s non contiene nessuna citazione.''',
'''Upload of attachment \'%(filename)s\'.''':
'''Allegato il file \'%(filename)s\'.''',
'''Drawing \'%(filename)s\' saved.''':
'''Il disegno \'%(filename)s\' è stato memorizzato.''',
'''%(mins)dm ago''':
'''%(mins)dmin fa''',
'''(no bookmark set)''':
'''(nessun segnalibro impostato)''',
'''(currently set to %s)''':
'''(attualmente impostato a %s)''',
'''Delete Bookmark''':
'''Cancella segnalibro''',
'''Set bookmark''':
'''Imposta segnalibro''',
'''set bookmark''':
'''imposta segnalibro''',
'''[Bookmark reached]''':
'''[Limite indicato dal segnalibro]''',
'''Contents''':
'''Contenuti''',
'''No wanted pages in this wiki.''':
'''Non ci sono pagine "non scritte" in questo wiki.''',
'''Invalid include arguments "%s"!''':
'''Argomento per "Include" non valido: "%s"!''',
'''Nothing found for "%s"!''':
'''Non trovato nulla per "%s"''',
'''Markup''':
'''Formattazione Wiki''',
'''Display''':
'''Mostra''',
'''Filename''':
'''Nome del file''',
'''Rendering of reStructured text is not possible, please install docutils.''':
'''Impossibile di visualizzare reStructured text, bisogna installare docutils.''',
'''**Maximum number of allowed includes exceeded**''':
'''**Superato il limite massimo di inclusioni consentite**''',
'''**Could not find the referenced page: %s**''':
'''**Impossibile trovare la pagina di rimando: %s**''',
'''Expected "%(wanted)s" after "%(key)s", got "%(token)s"''':
'''Atteso "%(wanted)s" dopo "%(key)s", trovato "%(token)s"''',
'''Expected an integer "%(key)s" before "%(token)s"''':
'''Atteso un intero "%(key)s" prima di "%(token)s"''',
'''Expected an integer "%(arg)s" after "%(key)s"''':
'''Atteso un intero "%(arg)s" dopo di "%(key)s"''',
'''Expected a color value "%(arg)s" after "%(key)s"''':
'''Atteso un colore "%(arg)s" dopo di "%(key)s"''',
'''XSLT option disabled, please look at HelpOnConfiguration.''':
'''Opzione XSLT disattivata, per favore consultare AiutoSuConfigurazione.''',
'''XSLT processing is not available, please install 4suite 1.x.''':
'''Elaborazione XSLT non disponibile, per favore installare 4suite 1.x.''',
'''%(errortype)s processing error''':
'''Errore di elaborazione di tipo "%(errortype)s"''',
'''Views/day''':
'''N. richieste a giornata''',
'''Edits/day''':
'''N. modifiche a giornata''',
'''%(chart_title)s for %(filterpage)s''':
'''%(chart_title)s: %(filterpage)s''',
'''green=view
red=edit''':
'''verde=Vis
rosso=Mod''',
'''date''':
'''data''',
'''# of hits''':
'''n. di accessi''',
'''Page Size Distribution''':
'''Distribuzione delle pagine per dimensione''',
'''page size upper bound [bytes]''':
'''dimensione massima della pagina [bytes]''',
'''# of pages of this size''':
'''n. di pagine di questa dimensione''',
'''User agent''':
'''Applicazione''',
'''Others''':
'''Altre''',
'''Distribution of User-Agent Types''':
'''Distribuzione delle tipologie di User-Agent''',
'''Unsubscribe''':
'''Annulla sottoscrizione''',
'''Home''':
'''Home''',
'''[RSS]''':
'''[RSS]''',
'''[DELETED]''':
'''[CANCELLATO]''',
'''[UPDATED]''':
'''[AGGIORNATO]''',
'''[NEW]''':
'''[NUOVO]''',
'''[DIFF]''':
'''[DIFFERENZE]''',
'''[BOTTOM]''':
'''[FINE]''',
'''[TOP]''':
'''[INIZIO]''',
'''Click to do a full-text search for this title''':
'''Clicca qui per effettuare una ricerca full-text per questo titolo''',
'''Preferences''':
'''Preferenze''',
'''Logout''':
'''Logout''',
'''Clear message''':
'''Nascondi questo messaggio''',
'''last edited %(time)s by %(editor)s''':
'''l\'ultima modifica è del %(time)s, fatta da %(editor)s''',
'''last modified %(time)s''':
'''modificata l\'ultima volta il %(time)s''',
'''Search:''':
'''Cerca:''',
'''Text''':
'''Testo''',
'''Titles''':
'''Titoli''',
'''Search''':
'''Cerca''',
'''More Actions:''':
'''Altre Azioni:''',
'''------------''':
'''------------''',
'''Raw Text''':
'''Mostra il testo grezzo''',
'''Delete Cache''':
'''Cancella file temporanei''',
'''Delete Page''':
'''Cancella Pagina''',
'''Like Pages''':
'''Pagine simili''',
'''Local Site Map''':
'''Mappa locale dell sito''',
'''My Pages''':
'''Pagine personali''',
'''Subscribe User''':
'''Abbona utente''',
'''Remove Spam''':
'''Rimuovi spam''',
'''Package Pages''':
'''Crea un package''',
'''Render as Docbook''':
'''Visualizza come Docbook''',
'''Do''':
'''Esegui''',
'''Edit (Text)''':
'''Modifica (modo testuale)''',
'''Edit (GUI)''':
'''Modifica (modo grafico)''',
'''Immutable Page''':
'''Pagina non alterabile''',
'''Remove Link''':
'''Rimuovi collegamento''',
'''Add Link''':
'''Aggiungi collegamento''',
'''Attachments''':
'''Allegati''',
'''Show %s days.''':
'''Mostra %s giorni.''',
'''DeleteCache''':
'''Cancella file temporanei''',
'''(cached %s)''':
'''(%s in cache)''',
'''Or try one of these actions:''':
'''Oppure prova una di queste azioni:''',
'''Page''':
'''Pagina''',
'''User''':
'''Utente''',
'''Sorry, can not save page because "%(content)s" is not allowed in this wiki.''':
'''Impossibile salvare la pagina, "%(content)s" non è ammesso in questo wiki.''',
'''Line''':
'''Linea''',
'''Deletions are marked like this.''':
'''Le cancellazioni sono marcate in questo modo.''',
'''Additions are marked like this.''':
'''Le aggiunte sono marcate in questo modo.''',
'''Connection to mailserver \'%(server)s\' failed: %(reason)s''':
'''La connessione al mailserver \'%(server)s\' è fallita: %(reason)s''',
'''Mail not sent''':
'''Email non spedita''',
'''Mail sent OK''':
'''Mail spedita correttamente''',
}
