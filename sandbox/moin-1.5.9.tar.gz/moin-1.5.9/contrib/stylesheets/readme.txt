speed.css - this file shows how admonitions in restructured text pages
            can be styled with CSS classes
