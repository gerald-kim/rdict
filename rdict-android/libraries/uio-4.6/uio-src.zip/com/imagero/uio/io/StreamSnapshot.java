package com.imagero.uio.io;

/**
 * StreamSnapshot represents an internal state of a stream.
 * Date: 25.06.2008
 *
 * @author Andrey Kuznetsov
 */
public class StreamSnapshot {
}
